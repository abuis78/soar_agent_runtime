"""Policy client interface shared by embedded and service mode (MCP-G02, RT-W01).

Python names are English; the wire format uses the spec names from
spec-policy-manager.md §5 (aktion, kontext, entscheidung_id, freigabe_id, ...).
Field names the spec does not define yet (principal_type, initiator, schritt_id,
artefakt_werte, status fields) are proposals, see docs/KONZEPT.md §7 (S3).

Fail-closed contract: no method raises to the caller. Errors become a DENY
decision with a code, a halted status, or a failed consume — a caller that
forgets error handling can never execute by accident.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Optional

from policy_core.layer import Gate

# Codes for DENY decisions and failed operations (PM §9; UNAVAILABLE/INVALID_RESPONSE client-side).
CODE_NO_EVIDENCE = "NO_EVIDENCE"
CODE_INCOMPLETE_JUDGEMENT = "INCOMPLETE_JUDGEMENT"
CODE_HALTED = "HALTED"
CODE_INVALID_SEQUENCE = "INVALID_SEQUENCE"
CODE_UNAVAILABLE = "UNAVAILABLE"
CODE_INVALID_RESPONSE = "INVALID_RESPONSE"
CODE_NO_INITIATOR = "NO_INITIATOR"
# Approval lifecycle codes.
CODE_SELF_APPROVAL = "SELF_APPROVAL"
CODE_DUPLICATE = "DUPLICATE"
CODE_NO_APPROVER = "NO_APPROVER"
CODE_UNKNOWN_APPROVAL = "UNKNOWN_APPROVAL"
CODE_NOT_APPROVED = "NOT_APPROVED"
CODE_ACTION_CHANGED = "ACTION_CHANGED"
CODE_EXPIRED = "EXPIRED"
CODE_CONSUMED = "CONSUMED"

APPROVAL_STATES = frozenset({"pending", "approved", "rejected", "expired", "consumed"})


def _str_list(value: Any) -> list[str]:
    if not isinstance(value, (list, tuple)):
        return []
    return [str(v) for v in value]


def _opt_float(value: Any) -> Optional[float]:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def _opt_int(value: Any) -> Optional[int]:
    try:
        return None if value is None else int(value)
    except (TypeError, ValueError):
        return None


@dataclass(frozen=True)
class DecisionRequest:
    """An action to be decided, plus the caller's context (PM §5 request)."""
    kind: str                                   # aktion.art, e.g. run_playbook
    category: str = ""                          # aktion.kategorie
    playbook: str = ""                          # aktion.playbook
    targets: tuple[str, ...] = ()               # aktion.ziel
    params: dict = field(default_factory=dict)  # aktion.parameter
    principal_type: str = ""                    # mensch | agent | broker (MCP-G01)
    initiator: str = ""                         # token identity or agent_id (MCP-W04)
    agent_id: str = ""
    run_id: str = ""                            # lauf_id
    step_id: str = ""                           # schritt_id
    stage: Optional[int] = None                 # stufe 0-4, None = not given
    domain: str = ""                            # domaene
    tipping_off: str = ""                       # laut | leise
    confidence: Optional[float] = None          # agent_konfidenz (human path only, MCP-W05)
    evidence_ids: tuple[str, ...] = ()          # beleg_ids
    judgement: dict = field(default_factory=dict)  # urteil
    artifact_values: tuple[str, ...] = ()       # artefakt_werte (MCP-W03)

    def to_wire(self) -> dict:
        action = {"art": self.kind, "kategorie": self.category, "playbook": self.playbook,
                  "ziel": list(self.targets), "parameter": dict(self.params)}
        context: dict[str, Any] = {
            "principal_type": self.principal_type, "initiator": self.initiator,
            "agent_id": self.agent_id, "lauf_id": self.run_id, "schritt_id": self.step_id,
            "domaene": self.domain, "tipping_off": self.tipping_off,
            "beleg_ids": list(self.evidence_ids), "urteil": dict(self.judgement),
            "artefakt_werte": list(self.artifact_values),
        }
        if self.stage is not None:
            context["stufe"] = self.stage
        if self.confidence is not None:
            context["agent_konfidenz"] = self.confidence
        return {"aktion": action, "kontext": context}

    @classmethod
    def from_wire(cls, data: Any) -> "DecisionRequest":
        """Parse a wire request. Malformed parts become empty values, which the
        decision rules treat as unknown (never as permissive)."""
        data = data if isinstance(data, dict) else {}
        action = data.get("aktion") if isinstance(data.get("aktion"), dict) else {}
        context = data.get("kontext") if isinstance(data.get("kontext"), dict) else {}
        params = action.get("parameter")
        judgement = context.get("urteil")
        return cls(
            kind=str(action.get("art") or ""),
            category=str(action.get("kategorie") or ""),
            playbook=str(action.get("playbook") or ""),
            targets=tuple(_str_list(action.get("ziel"))),
            params=params if isinstance(params, dict) else {},
            principal_type=str(context.get("principal_type") or ""),
            initiator=str(context.get("initiator") or ""),
            agent_id=str(context.get("agent_id") or ""),
            run_id=str(context.get("lauf_id") or ""),
            step_id=str(context.get("schritt_id") or ""),
            stage=_opt_int(context.get("stufe")),
            domain=str(context.get("domaene") or ""),
            tipping_off=str(context.get("tipping_off") or ""),
            confidence=_opt_float(context.get("agent_konfidenz")),
            evidence_ids=tuple(_str_list(context.get("beleg_ids"))),
            judgement=judgement if isinstance(judgement, dict) else {},
            artifact_values=tuple(_str_list(context.get("artefakt_werte"))),
        )


@dataclass(frozen=True)
class Decision:
    """Result of decide() (PM-F08)."""
    decision_id: str
    gate: Gate
    approvals_needed: int = 0
    risk_score: float = 0.0
    policy_version: str = ""
    reasons: tuple[dict, ...] = ()
    approval_id: str = ""
    expires_at: str = ""
    code: str = ""

    @property
    def allowed(self) -> bool:
        return self.gate == Gate.ALLOW

    @classmethod
    def deny(cls, code: str, reason: str = "", decision_id: str = "") -> "Decision":
        reasons = ({"regel": "client", "grund": reason, "gate": Gate.DENY.name},) if reason else ()
        return cls(decision_id=decision_id, gate=Gate.DENY, reasons=reasons, code=code)

    def to_wire(self) -> dict:
        data: dict[str, Any] = {
            "entscheidung_id": self.decision_id, "gate": self.gate.name,
            "freigaben_noetig": self.approvals_needed, "risiko_score": self.risk_score,
            "policy_version": self.policy_version, "begruendung": [dict(r) for r in self.reasons],
        }
        if self.approval_id:
            data["freigabe_id"] = self.approval_id
        if self.expires_at:
            data["ablauf"] = self.expires_at
        if self.code:
            data["code"] = self.code
        return data

    @classmethod
    def from_wire(cls, data: Any) -> "Decision":
        """Parse a wire decision. Never raises: anything malformed is DENY."""
        if not isinstance(data, dict) or "gate" not in data:
            return cls.deny(CODE_INVALID_RESPONSE, "malformed decision")
        gate = Gate.from_name(data.get("gate"))   # unknown name -> DENY
        if gate == Gate.ALLOW and not data.get("entscheidung_id"):
            # Execution must trace back to a decision (AN-06/AN-07, D22).
            return cls.deny(CODE_INVALID_RESPONSE, "ALLOW without entscheidung_id")
        needed = _opt_int(data.get("freigaben_noetig"))
        reasons = data.get("begruendung")
        return cls(
            decision_id=str(data.get("entscheidung_id") or ""),
            gate=gate,
            approvals_needed=needed if needed is not None else 0,
            risk_score=_opt_float(data.get("risiko_score")) or 0.0,
            policy_version=str(data.get("policy_version") or ""),
            reasons=tuple(r for r in reasons if isinstance(r, dict)) if isinstance(reasons, list) else (),
            approval_id=str(data.get("freigabe_id") or ""),
            expires_at=str(data.get("ablauf") or ""),
            code=str(data.get("code") or ""),
        )


@dataclass(frozen=True)
class ApprovalStatus:
    """State of an approval (GET /v1/approvals/{id})."""
    approval_id: str
    status: str            # one of APPROVAL_STATES; anything else is treated as expired
    have: int = 0
    need: int = 0
    code: str = ""         # why an approve/reject was not counted, e.g. SELF_APPROVAL

    def to_wire(self) -> dict:
        data: dict[str, Any] = {"freigabe_id": self.approval_id, "status": self.status,
                                "erteilt": self.have, "noetig": self.need}
        if self.code:
            data["code"] = self.code
        return data

    @classmethod
    def from_wire(cls, data: Any) -> "ApprovalStatus":
        data = data if isinstance(data, dict) else {}
        status = str(data.get("status") or "")
        return cls(
            approval_id=str(data.get("freigabe_id") or ""),
            status=status if status in APPROVAL_STATES else "expired",
            have=_opt_int(data.get("erteilt")) or 0,
            need=_opt_int(data.get("noetig")) or 0,
            code=str(data.get("code") or ""),
        )


@dataclass(frozen=True)
class ConsumeResult:
    """Outcome of consume() (PM-F23). Only ok=True permits execution."""
    ok: bool
    code: str = ""

    def to_wire(self) -> dict:
        data: dict[str, Any] = {"gueltig": self.ok}
        if self.code:
            data["code"] = self.code
        return data

    @classmethod
    def from_wire(cls, data: Any) -> "ConsumeResult":
        if not isinstance(data, dict) or data.get("gueltig") is not True:
            code = str(data.get("code") or "") if isinstance(data, dict) else ""
            return cls(ok=False, code=code or CODE_INVALID_RESPONSE)
        return cls(ok=True, code=str(data.get("code") or ""))


@dataclass(frozen=True)
class HaltStatus:
    """Emergency stop state (PM-F30/F31). Unknown state means halted."""
    halted: bool
    reason: str = ""

    def to_wire(self) -> dict:
        return {"angehalten": self.halted, "grund": self.reason}

    @classmethod
    def from_wire(cls, data: Any) -> "HaltStatus":
        if not isinstance(data, dict) or data.get("angehalten") is not False:
            reason = str(data.get("grund") or "") if isinstance(data, dict) else ""
            return cls(halted=True, reason=reason or "unknown halt state")
        return cls(halted=False, reason=str(data.get("grund") or ""))


class PolicyClient(abc.ABC):
    """One interface for embedded and service mode. Implementations never raise."""

    @abc.abstractmethod
    def decide(self, request: DecisionRequest) -> Decision:
        """POST /v1/decide."""

    @abc.abstractmethod
    def approve(self, approval_id: str, approver: str) -> ApprovalStatus:
        """POST /v1/approvals/{id}/approve — one authenticated person (PM-F21)."""

    @abc.abstractmethod
    def reject(self, approval_id: str, approver: str) -> ApprovalStatus:
        """POST /v1/approvals/{id}/reject."""

    @abc.abstractmethod
    def approval_status(self, approval_id: str) -> ApprovalStatus:
        """GET /v1/approvals/{id}."""

    @abc.abstractmethod
    def consume(self, approval_id: str, request: DecisionRequest) -> ConsumeResult:
        """POST /v1/approvals/{id}/consume — valid only for the unchanged action."""

    @abc.abstractmethod
    def halt_status(self) -> HaltStatus:
        """GET /v1/halt."""

    @abc.abstractmethod
    def actions(self, agent_id: str) -> list[dict]:
        """GET /v1/aktionen?agent_id= — empty list means no building blocks."""
