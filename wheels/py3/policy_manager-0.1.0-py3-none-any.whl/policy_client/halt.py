"""Emergency stop for embedded mode: a halt file owned by the management domain (E9, W12).

The file holds the HaltStatus wire format, e.g. {"angehalten": false, "grund": "..."}.
Fail-safe (D25, PM-F31): a missing, unreadable, malformed or world-writable file
means halted. Only an explicit "angehalten": false lets agent runs proceed.
The file is re-read on every call so a halt takes effect immediately.
"""
from __future__ import annotations

import json
import os
import stat

from policy_client.base import HaltStatus


class HaltFile:
    def __init__(self, path: str) -> None:
        self._path = path

    def status(self) -> HaltStatus:
        try:
            mode = os.stat(self._path).st_mode
        except OSError:
            return HaltStatus(halted=True, reason="halt file missing")
        if mode & stat.S_IWOTH:
            # Anyone could lift the halt -> not trustworthy.
            return HaltStatus(halted=True, reason="unsafe permissions on halt file")
        try:
            with open(self._path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return HaltStatus(halted=True, reason="halt file unreadable")
        return HaltStatus.from_wire(data)
