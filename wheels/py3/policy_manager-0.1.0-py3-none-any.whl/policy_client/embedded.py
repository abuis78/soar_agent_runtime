"""Embedded mode: the policy decision runs in-process (E8, SPEC-RT phase 3).

EmbeddedPolicyClient decides with policy_core.layer (behaviour 1:1 with
soar_mcp_server), keeps approvals in a file-backed LifecycleStore and reads the
emergency stop from a halt file (E9). Two additions over today, both only
tightening: agent requests are DENY (HALTED) while halted, and no approval is
opened without an initiator (the action stays held, like today without a
scoped token).

LifecycleStore reuses ApprovalStore's file, lock and hashing, but separates
approve from consume (PM-F23): pending -> approved -> consumed, or rejected /
expired. Approvals are bound to the action (art, kategorie, playbook, ziel,
parameter) only — a changed judgement or context does not break consume (W6).
Only SHA-256 hashes of approval ids are stored (PM-F42).
"""
from __future__ import annotations

import hashlib
import logging
import secrets
import time
from dataclasses import replace
from datetime import datetime, timezone
from typing import Optional

from policy_client.approvals import ApprovalStore
from policy_client.base import (
    CODE_ACTION_CHANGED, CODE_CONSUMED, CODE_DUPLICATE, CODE_EXPIRED, CODE_HALTED,
    CODE_NO_APPROVER, CODE_NO_INITIATOR, CODE_NOT_APPROVED, CODE_SELF_APPROVAL,
    CODE_UNAVAILABLE, CODE_UNKNOWN_APPROVAL, ApprovalStatus, ConsumeResult, Decision,
    DecisionRequest, HaltStatus, PolicyClient,
)
from policy_client.halt import HaltFile
from policy_core.layer import ActionContext, Gate, PolicyLayer

log = logging.getLogger("policy_client.embedded")

_TTL_DEFAULT = 600.0          # 10 min, as today (PM-F22)
_KEEP_AFTER_EXPIRY = 3600.0   # keep finished entries so status queries stay meaningful


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).isoformat()


def _binding(request: DecisionRequest) -> dict:
    """What an approval is bound to: the action itself, never its context (W6)."""
    return {"art": request.kind, "kategorie": request.category, "playbook": request.playbook,
            "ziel": list(request.targets), "parameter": dict(request.params)}


class LifecycleStore(ApprovalStore):
    """Approval lifecycle with separate consume. Entries are dicts:
    {tool, args, exp, need, approvers, initiator, principal, state}."""

    @staticmethod
    def _prune(data: dict) -> dict:
        now = time.time()
        return {k: v for k, v in data.items()
                if isinstance(v, dict) and float(v.get("exp", 0)) + _KEEP_AFTER_EXPIRY > now}

    def open(self, tool: str, args: dict, needed: int, initiator: str, principal: str,
             ttl: float = _TTL_DEFAULT) -> tuple[str, float]:
        token = "ap_" + secrets.token_urlsafe(16)
        exp = time.time() + ttl
        with self._lock, self._file_lock():
            data = self._prune(self._load())
            data[self._token_hash(token)] = {
                "tool": tool, "args": self._args_hash(tool, args), "exp": exp,
                "need": max(1, int(needed)), "approvers": [], "initiator": initiator.strip(),
                "principal": principal, "state": "pending",
            }
            self._save(data)
        return token, exp

    @staticmethod
    def _status(token: str, entry: Optional[dict], code: str = "") -> ApprovalStatus:
        if entry is None:
            return ApprovalStatus(token, "expired", code=code or CODE_UNKNOWN_APPROVAL)
        return ApprovalStatus(token, entry["state"], have=len(entry["approvers"]),
                              need=int(entry["need"]), code=code)

    @staticmethod
    def _expire(entry: dict) -> None:
        if entry["state"] in ("pending", "approved") and float(entry["exp"]) <= time.time():
            entry["state"] = "expired"

    def _entry(self, data: dict, token: str) -> Optional[dict]:
        entry = data.get(self._token_hash(str(token)))
        return entry if isinstance(entry, dict) else None

    def status(self, token: str) -> ApprovalStatus:
        with self._lock, self._file_lock():
            entry = self._entry(self._load(), token)
            if entry is not None:
                self._expire(entry)
            return self._status(token, entry)

    def approve(self, token: str, approver: str, halted: bool) -> ApprovalStatus:
        approver = (approver or "").strip()
        with self._lock, self._file_lock():
            data = self._load()
            entry = self._entry(data, token)
            if entry is None:
                return self._status(token, None)
            self._expire(entry)
            if entry["state"] != "pending":
                return self._status(token, entry, CODE_EXPIRED if entry["state"] == "expired" else "")
            if not approver:
                return self._status(token, entry, CODE_NO_APPROVER)
            if entry["principal"] == "agent" and halted:
                entry["state"] = "expired"   # open agent approvals become invalid (PM-F30)
                self._save(data)
                return self._status(token, entry, CODE_HALTED)
            if entry["initiator"] and approver == entry["initiator"]:
                return self._status(token, entry, CODE_SELF_APPROVAL)
            if approver in entry["approvers"]:
                return self._status(token, entry, CODE_DUPLICATE)
            entry["approvers"].append(approver)
            if len(entry["approvers"]) >= int(entry["need"]):
                entry["state"] = "approved"
            self._save(data)
            return self._status(token, entry)

    def reject(self, token: str, approver: str) -> ApprovalStatus:
        approver = (approver or "").strip()
        with self._lock, self._file_lock():
            data = self._load()
            entry = self._entry(data, token)
            if entry is None:
                return self._status(token, None)
            self._expire(entry)
            if not approver:
                return self._status(token, entry, CODE_NO_APPROVER)
            if entry["state"] in ("pending", "approved"):
                entry["state"] = "rejected"
                self._save(data)
            return self._status(token, entry)

    def consume(self, token: str, tool: str, args: dict, halted: bool) -> ConsumeResult:
        with self._lock, self._file_lock():
            data = self._load()
            entry = self._entry(data, token)
            if entry is None:
                return ConsumeResult(False, CODE_UNKNOWN_APPROVAL)
            self._expire(entry)
            state = entry["state"]
            if state == "consumed":
                return ConsumeResult(False, CODE_CONSUMED)
            if state == "expired":
                return ConsumeResult(False, CODE_EXPIRED)
            if state != "approved":
                return ConsumeResult(False, CODE_NOT_APPROVED)
            # Changed action must NOT destroy a legitimate approval.
            if entry["tool"] != tool or entry["args"] != self._args_hash(tool, args):
                return ConsumeResult(False, CODE_ACTION_CHANGED)
            if entry["principal"] == "agent" and halted:
                entry["state"] = "expired"   # PM-F30
                self._save(data)
                return ConsumeResult(False, CODE_HALTED)
            entry["state"] = "consumed"      # single use (PM-F22/F23)
            self._save(data)
            return ConsumeResult(True)


class EmbeddedPolicyClient(PolicyClient):
    """In-process policy decisions. Never raises; errors fail closed."""

    def __init__(self, policy_path: str, approvals_path: str, halt_path: str,
                 ttl: float = _TTL_DEFAULT) -> None:
        self._policy = PolicyLayer(policy_path)      # missing/broken -> DENY defaults
        self._version = self._file_version(policy_path)
        self._store = LifecycleStore(approvals_path)
        self._halt = HaltFile(halt_path)
        self._ttl = ttl

    @staticmethod
    def _file_version(path: str) -> str:
        try:
            with open(path, "rb") as fh:
                return hashlib.sha256(fh.read()).hexdigest()[:12]
        except OSError:
            return ""

    def _halted(self) -> bool:
        return self.halt_status().halted

    def decide(self, request: DecisionRequest) -> Decision:
        try:
            return self._decide(request)
        except Exception as exc:
            log.error("[policy_client] decide failed: %s -> DENY", exc)
            return Decision.deny(CODE_UNAVAILABLE, f"embedded decide failed ({type(exc).__name__})")

    def _decide(self, request: DecisionRequest) -> Decision:
        decision_id = "pm-" + secrets.token_hex(8)
        if request.principal_type == "agent" and self._halted():
            return Decision.deny(CODE_HALTED, "agent chain halted", decision_id=decision_id)

        enrich = {"target_asset_tags": [], "target_identity_tags": [], "asset_criticality": 0.0}
        if self._policy.asset_context_enabled and request.artifact_values:
            enrich = self._policy.enrich(list(request.artifact_values))
        try:
            playbook_id = int(request.params.get("playbook_id", 0))
        except (TypeError, ValueError):
            playbook_id = 0
        ctx = ActionContext(
            playbook_id=playbook_id,
            playbook_name=request.playbook,
            category=request.category,
            reversible=self._policy.category_is_reversible(request.category),  # never the caller
            agent_confidence=0.5 if request.confidence is None else request.confidence,
            asset_criticality=enrich["asset_criticality"],
            target_asset_tags=enrich["target_asset_tags"],
            target_identity_tags=enrich["target_identity_tags"],
        )
        pd = self._policy.evaluate(ctx)
        reasons = ({"regel": "policy_layer", "grund": pd.reason, "gate": pd.gate.name},)
        decision = Decision(decision_id=decision_id, gate=pd.gate,
                            approvals_needed=pd.needed_approvers, risk_score=round(pd.risk_score, 3),
                            policy_version=self._version, reasons=reasons)
        if pd.gate not in (Gate.APPROVE_1CLICK, Gate.APPROVE_2PERSON):
            return decision
        if not request.initiator.strip():
            # No accountable initiator -> no approval process, action stays held.
            return replace(decision, code=CODE_NO_INITIATOR)
        token, exp = self._store.open(request.kind, _binding(request), pd.needed_approvers,
                                      request.initiator, request.principal_type, self._ttl)
        return replace(decision, approval_id=token, expires_at=_iso(exp))

    def approve(self, approval_id: str, approver: str) -> ApprovalStatus:
        try:
            return self._store.approve(approval_id, approver, self._halted())
        except Exception as exc:
            log.error("[policy_client] approve failed: %s", exc)
            return ApprovalStatus(approval_id, "expired", code=CODE_UNAVAILABLE)

    def reject(self, approval_id: str, approver: str) -> ApprovalStatus:
        try:
            return self._store.reject(approval_id, approver)
        except Exception as exc:
            log.error("[policy_client] reject failed: %s", exc)
            return ApprovalStatus(approval_id, "expired", code=CODE_UNAVAILABLE)

    def approval_status(self, approval_id: str) -> ApprovalStatus:
        try:
            return self._store.status(approval_id)
        except Exception as exc:
            log.error("[policy_client] approval_status failed: %s", exc)
            return ApprovalStatus(approval_id, "expired", code=CODE_UNAVAILABLE)

    def consume(self, approval_id: str, request: DecisionRequest) -> ConsumeResult:
        try:
            return self._store.consume(approval_id, request.kind, _binding(request), self._halted())
        except Exception as exc:
            log.error("[policy_client] consume failed: %s", exc)
            return ConsumeResult(False, CODE_UNAVAILABLE)

    def halt_status(self) -> HaltStatus:
        try:
            return self._halt.status()
        except Exception as exc:
            return HaltStatus(halted=True, reason=f"halt check failed ({type(exc).__name__})")

    def actions(self, agent_id: str) -> list[dict]:
        return []   # action catalogue arrives in P4; empty = no building blocks
