"""Emergency stop for embedded mode: a halt file owned by the management domain (E9, W12).

The file holds the HaltStatus wire format, e.g. {"angehalten": false, "grund": "..."}.
Fail-safe (D25, PM-F31): a missing, unreadable, malformed or world-writable file
means halted. Only an explicit "angehalten": false lets agent runs proceed.
The file is re-read on every call so a halt takes effect immediately.
"""
from __future__ import annotations

import json
import os
import stat
import tempfile

from policy_client.base import HaltStatus


class HaltFile:
    def __init__(self, path: str) -> None:
        self._path = path

    def status(self) -> HaltStatus:
        try:
            mode = os.stat(self._path).st_mode
        except OSError:
            return HaltStatus(halted=True, reason="halt file missing", known=False)
        if mode & stat.S_IWOTH:
            # Anyone could lift the halt -> not trustworthy.
            return HaltStatus(halted=True, reason="unsafe permissions on halt file", known=False)
        try:
            with open(self._path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return HaltStatus(halted=True, reason="halt file unreadable", known=False)
        return HaltStatus.from_wire(data)

    def set(self, halted: bool, reason: str) -> HaltStatus:
        """Write the state atomically (temp file + replace), mode 0644. Raises OSError."""
        status = HaltStatus(halted=bool(halted), reason=str(reason))
        directory = os.path.dirname(os.path.abspath(self._path))
        fd, tmp = tempfile.mkstemp(dir=directory, prefix=".halt-")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(status.to_wire(), fh)
                fh.flush()
                os.fsync(fh.fileno())
            os.chmod(tmp, 0o644)
            os.replace(tmp, self._path)
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise
        return status
