"""Service configuration from a TOML file (P3.6).

    [server]
    host = "127.0.0.1"          # default
    port = 8443
    cert = "certs/server.crt"   # server certificate (PEM)
    key  = "certs/server.key"
    ca   = "certs/ca.crt"       # CA that signs the client certificates

    [policy]
    path = "policy_config.toml"

    [state]
    dir = "state"               # approvals.json, halt.json, audit.jsonl, sequences.json
    ttl_s = 600                 # approval lifetime (PM-F22)

    [clients]                   # certificate CN -> roles
    "soar-mcp" = ["decide"]

Relative paths are resolved against the directory of the config file, so the
whole setup can live in one folder outside the repo (L17).
"""
from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass

from policy_service.app import ROLES, ServiceConfig


@dataclass(frozen=True)
class ServerConfig:
    host: str
    port: int
    cert: str
    key: str
    ca: str
    service: ServiceConfig


def _table(data: dict, name: str) -> dict:
    value = data.get(name)
    if not isinstance(value, dict):
        raise ValueError(f"[{name}] section missing")
    return value


def _string(section: dict, name: str, key: str, default: str | None = None) -> str:
    value = section.get(key, default)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"[{name}] {key} must be a non-empty string")
    return value


def _path(base: str, section: dict, name: str, key: str) -> str:
    value = os.path.expanduser(_string(section, name, key))
    return value if os.path.isabs(value) else os.path.normpath(os.path.join(base, value))


def load_config(path: str) -> ServerConfig:
    """Read and validate the service config. Raises ValueError with a readable message."""
    try:
        with open(path, "rb") as fh:
            data = tomllib.load(fh)
    except OSError as exc:
        raise ValueError(f"cannot read config {path}: {exc.strerror}") from None
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"config {path} is not valid TOML: {exc}") from None
    base = os.path.dirname(os.path.abspath(path))

    server, policy, state = _table(data, "server"), _table(data, "policy"), _table(data, "state")
    port = server.get("port")
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("[server] port must be a number 1-65535")
    ttl = state.get("ttl_s", 600)
    if isinstance(ttl, bool) or not isinstance(ttl, (int, float)) or ttl <= 0:
        raise ValueError("[state] ttl_s must be a positive number")

    clients_raw = _table(data, "clients")
    clients: dict[str, frozenset[str]] = {}
    for cn, roles in clients_raw.items():
        if not isinstance(roles, list) or not roles or not all(isinstance(r, str) for r in roles):
            raise ValueError(f"[clients] {cn!r} needs a non-empty list of roles")
        unknown = set(roles) - ROLES
        if unknown:
            raise ValueError(f"[clients] {cn!r} has unknown roles {sorted(unknown)}; "
                             f"allowed: {sorted(ROLES)}")
        clients[cn] = frozenset(roles)
    if not clients:
        raise ValueError("[clients] must name at least one client")

    return ServerConfig(
        host=_string(server, "server", "host", "127.0.0.1"),
        port=port,
        cert=_path(base, server, "server", "cert"),
        key=_path(base, server, "server", "key"),
        ca=_path(base, server, "server", "ca"),
        service=ServiceConfig(policy_path=_path(base, policy, "policy", "path"),
                              state_dir=_path(base, state, "state", "dir"),
                              clients=clients, ttl=float(ttl)),
    )
