"""Decision engine: policy layer plus P2 rules, strictest gate wins (PM-F02).

PolicyEngine reads one policy file. The policy layer (category, risk, target;
behaviour 1:1 with soar_mcp_server) is one entry in the reasons, every rule from
policy_core.rules another (W4). The halt state is an input, so the result
depends only on request, policy and halt state (PM-N02, W5).

Optional P2 sections in the same file (keys in English like the rest of it):
  tool_action_kinds                {"<tool>": "<action kind>"}        SPEC-MCP §3.4
  agent_denied_kinds               ["<action kind>", ...]
  stage_min_gate                   {"0": "<GATE>", ... "4": "<GATE>"}  PM-F03
  stage_min_gate_high_criticality  {"2": "<GATE>"}
  high_criticality_threshold       0.0 .. 1.0 (default 0.5)
A missing section is empty: agents get the strict behaviour, humans today's.
A present but malformed section makes every decision DENY (POLICY_INVALID).
The same holds for the action catalogue ([building_blocks], [sequence_rules],
see policy_core.catalog; P4).
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Optional, Union

from policy_core import rules, sequence
from policy_core.catalog import Catalog, CatalogError, load_catalog
from policy_core.layer import ActionContext, Gate, PolicyLayer
from policy_core.model import CODE_POLICY_INVALID, PRINCIPAL_AGENT, SEQUENCE, DecisionRequest
from policy_core.rules import RUN_PLAYBOOK, RuleResult

_HIGH_CRITICALITY_DEFAULT = 0.5
_STAGES = range(0, 5)


class _InvalidPolicy(ValueError):
    pass


@dataclass(frozen=True)
class _RuleConfig:
    tool_kinds: dict[str, str]
    denied_kinds: frozenset[str]
    stage_gates: dict[int, Gate]
    high_crit_gates: dict[int, Gate]
    high_crit_threshold: float
    default: Gate


@dataclass(frozen=True)
class Outcome:
    gate: Gate
    approvals_needed: int
    risk_score: float
    reasons: tuple[dict, ...]
    code: str = ""


def _str_map(cfg: dict, key: str) -> dict[str, str]:
    value = cfg.get(key, {})
    if not isinstance(value, dict) or not all(
            isinstance(k, str) and isinstance(v, str) and v.strip() for k, v in value.items()):
        raise _InvalidPolicy(f"{key} must map names to non-empty strings")
    return dict(value)


def _str_list(cfg: dict, key: str) -> frozenset[str]:
    value = cfg.get(key, [])
    if not isinstance(value, list) or not all(isinstance(v, str) for v in value):
        raise _InvalidPolicy(f"{key} must be a list of strings")
    return frozenset(value)


def _stage_map(cfg: dict, key: str) -> dict[int, Gate]:
    value = cfg.get(key, {})
    if not isinstance(value, dict):
        raise _InvalidPolicy(f"{key} must map stages 0-4 to gate names")
    result = {}
    for k, v in value.items():
        try:
            stage = int(k)
        except (TypeError, ValueError):
            raise _InvalidPolicy(f"{key}: stage {k!r} is not a number") from None
        if stage not in _STAGES:
            raise _InvalidPolicy(f"{key}: stage {stage} outside 0-4")
        result[stage] = Gate.from_name(v)          # unknown gate name -> DENY
    return result


def _threshold(cfg: dict) -> float:
    value = cfg.get("high_criticality_threshold", _HIGH_CRITICALITY_DEFAULT)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0.0 <= value <= 1.0:
        raise _InvalidPolicy("high_criticality_threshold must be a number in 0..1")
    return float(value)


def _rule_config(cfg: dict) -> _RuleConfig:
    return _RuleConfig(
        tool_kinds=_str_map(cfg, "tool_action_kinds"),
        denied_kinds=_str_list(cfg, "agent_denied_kinds"),
        stage_gates=_stage_map(cfg, "stage_min_gate"),
        high_crit_gates=_stage_map(cfg, "stage_min_gate_high_criticality"),
        high_crit_threshold=_threshold(cfg),
        default=Gate.from_name(cfg.get("default_gate", "DENY")),   # as PolicyLayer
    )


def _approvals_needed(gate: Gate) -> int:
    return {Gate.APPROVE_1CLICK: 1, Gate.APPROVE_2PERSON: 2}.get(gate, 0)


class PolicyEngine:
    def __init__(self, policy_path: Union[str, Path]) -> None:
        self._layer = PolicyLayer(policy_path)     # missing/broken file -> DENY defaults
        self._catalog = Catalog()
        try:
            self._rules: Union[_RuleConfig, None] = _rule_config(self._layer.config)
            self._catalog = load_catalog(self._layer.config)
            self._invalid = ""
        except (_InvalidPolicy, CatalogError) as exc:
            self._rules, self._invalid = None, str(exc)

    @property
    def invalid_reason(self) -> str:
        """Why the policy cannot be used; "" when it is usable (PM-F60 ready)."""
        if self._invalid:
            return self._invalid
        return "" if self._layer.config else "policy missing or unreadable"

    @property
    def catalog(self) -> Catalog:
        """Action catalogue and sequence rules; empty when the policy is invalid."""
        return self._catalog

    def actions(self, agent_id: str) -> list[dict]:
        """Building blocks released for agent_id (GET /v1/aktionen, PM-F12, RT-W09).
        umkehrbar is the effective value: false once the policy says irreversible (H4).
        Blocklist, loud and agents stay inside the policy manager."""
        if not agent_id or self._rules is None:
            return []
        return [{
            "id": b.id, "version": b.version, "zweck": b.purpose, "kategorie": b.category,
            "zieltypen": list(b.target_types), "parameter": dict(b.parameters),
            "mindeststufe": b.min_stage,
            "umkehrbar": b.reversible and self._layer.category_is_reversible(b.category),
            "ruecknahme": b.undo, "mindest_gate": b.min_gate.name,
        } for b in sorted(self._catalog.blocks.values(), key=lambda b: b.id)
            if agent_id in b.agents]

    @property
    def config(self) -> dict:
        """Copy of the loaded policy (GET /v1/policy)."""
        return self._layer.config

    def _confidence(self, request: DecisionRequest) -> tuple[float, str]:
        if request.principal_type == PRINCIPAL_AGENT:
            # Agents: only the checked judgement counts (MCP-W05).
            value = rules.judgement_confidence(request.judgement)
            why = f"urteil.konfidenz={value}" if value is not None else "urteil.konfidenz missing -> 0.0"
            if request.confidence is not None:
                why += f"; agent_konfidenz={request.confidence} ignored"
            return (0.0 if value is None else value), why
        value = 0.5 if request.confidence is None else request.confidence
        return value, f"agent_konfidenz={value}"

    def _action(self, request: DecisionRequest, reversible: Optional[bool] = None) -> _Action:
        """Rules that depend on the action itself; shared by single actions and steps."""
        cfg, layer = self._rules, self._layer
        assert cfg is not None
        category, category_reason = rules.resolve_category(request, cfg.tool_kinds)
        enrich: dict[str, Any] = {"target_asset_tags": [], "target_identity_tags": [],
                                  "asset_criticality": 0.0}
        if layer.asset_context_enabled and request.artifact_values:
            enrich = layer.enrich(list(request.artifact_values))
        try:
            playbook_id = int(request.params.get("playbook_id", 0))
        except (TypeError, ValueError):
            playbook_id = 0
        confidence, confidence_reason = self._confidence(request)
        if reversible is None:
            reversible = layer.category_is_reversible(category)      # never the caller
        else:
            reversible = reversible and layer.category_is_reversible(category)   # H4
        pd = layer.evaluate(ActionContext(
            playbook_id=playbook_id,
            playbook_name=request.playbook,
            category=category,
            reversible=reversible,
            agent_confidence=confidence,
            asset_criticality=enrich["asset_criticality"],
            target_asset_tags=enrich["target_asset_tags"],
            target_identity_tags=enrich["target_identity_tags"],
        ))
        return _Action(
            layer=RuleResult("policy_layer", pd.gate, f"{category_reason}; {pd.reason}"),
            confidence=RuleResult("konfidenz", Gate.ALLOW, confidence_reason),
            kind=rules.agent_kind(request, category, cfg.denied_kinds),
            stage=rules.stage(request, cfg.stage_gates, cfg.high_crit_gates,
                              enrich["asset_criticality"], cfg.high_crit_threshold, cfg.default),
            irreversible=rules.irreversible(request, reversible),
            domain=rules.domain(request),
            risk=pd.risk_score,
        )

    def _tags(self, targets: tuple[str, ...]) -> set[str]:
        if not (self._layer.asset_context_enabled and targets):
            return set()
        enrich = self._layer.enrich(list(targets))
        return set(enrich["target_asset_tags"]) | set(enrich["target_identity_tags"])

    def evaluate(self, request: DecisionRequest, halted: bool,
                 sequence_known: bool = False) -> Outcome:
        """sequence_known: the sequence is in the register (PM-F11); default new."""
        if self._rules is None:
            reason = RuleResult("policy", Gate.DENY, self._invalid, CODE_POLICY_INVALID)
            return Outcome(Gate.DENY, 0, 0.0, (reason.to_wire(),), CODE_POLICY_INVALID)
        if request.kind == SEQUENCE:
            return self._evaluate_sequence(request, halted, sequence_known)
        a = self._action(request)
        results = [
            a.layer, a.confidence,
            rules.principal(request),
            rules.halt(request, halted),
            rules.evidence(request),
            rules.judgement(request),
            a.kind, a.stage, a.irreversible, a.domain,
        ]
        return _outcome([(None, r) for r in results], a.risk)

    def _evaluate_sequence(self, request: DecisionRequest, halted: bool,
                           known: bool) -> Outcome:
        """Catalogue and combination rules first, then context, then every step (PM-F10)."""
        catalog = self._catalog
        results: list[sequence.Indexed] = []
        results += sequence.catalog_check(request, catalog)
        results += sequence.combination_check(request, catalog, self._tags)
        results.append((None, sequence.new_sequence(request, catalog, known)))
        results += [(None, rules.principal(request)), (None, rules.halt(request, halted)),
                    (None, rules.evidence(request)), (None, rules.judgement(request))]
        risk = 0.0
        for i, (step, block) in enumerate(zip(request.steps, sequence.blocks_of(request, catalog))):
            if block is None:
                continue                                  # already DENY from the catalogue
            step_request = replace(
                request, kind=RUN_PLAYBOOK, category=block.category, playbook=block.playbook,
                targets=step.targets, params=dict(step.params),
                tipping_off="laut" if block.loud else "leise",      # catalogue wins (PM-F12)
                domain=block.domain or request.domain,
                artifact_values=tuple(step.targets) + tuple(request.artifact_values), steps=())
            a = self._action(step_request, reversible=block.reversible)
            results += [(i, r) for r in (a.layer, a.confidence, a.kind, a.stage,
                                         a.irreversible, a.domain, sequence.min_gate(block))]
            risk = max(risk, a.risk)
        return _outcome(results, risk)


@dataclass(frozen=True)
class _Action:
    layer: RuleResult
    confidence: RuleResult
    kind: RuleResult
    stage: RuleResult
    irreversible: RuleResult
    domain: RuleResult
    risk: float


def _outcome(results: list[tuple[Optional[int], RuleResult]], risk: float) -> Outcome:
    """Strictest gate wins (PM-F02); the first DENY code is the answer's code."""
    gate = max(r.gate for _, r in results)
    code = next((r.code for _, r in results if r.gate == Gate.DENY and r.code), "")
    reasons = tuple(r.to_wire() if i is None else {**r.to_wire(), "schritt": i}
                    for i, r in results)
    return Outcome(gate=gate, approvals_needed=_approvals_needed(gate),
                   risk_score=round(risk, 3), reasons=reasons, code=code)
