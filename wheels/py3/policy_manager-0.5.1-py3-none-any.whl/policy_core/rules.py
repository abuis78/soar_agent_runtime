"""Decision rules beyond the policy layer (P2, PM-F03-F07, F25, F30).

Each rule is a pure function returning a RuleResult. The engine takes the
strictest gate of all results, so no rule can relax another (PM-F02). A rule
that does not apply still returns a result (ALLOW, "not applicable") so the
reasons list every rule (W4).

Agent context comes only from principal_type, never from present or missing
arguments (W1, S1).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from policy_core.layer import Gate
from policy_core.model import (
    CODE_HALTED, CODE_INCOMPLETE_JUDGEMENT, CODE_NO_EVIDENCE, CODE_NOT_ALLOWED_FOR_AGENT,
    CODE_PRINCIPAL_NOT_ALLOWED,
    PRINCIPAL_AGENT, PRINCIPAL_HUMAN, DecisionRequest,
)

_NOT_APPLICABLE = "not applicable (mensch)"
RUN_PLAYBOOK = "run_playbook"


@dataclass(frozen=True)
class RuleResult:
    rule: str
    gate: Gate
    reason: str = ""
    code: str = ""

    def to_wire(self) -> dict:
        data = {"regel": self.rule, "gate": self.gate.name, "grund": self.reason}
        if self.code:
            data["code"] = self.code
        return data


def _is_agent(request: DecisionRequest) -> bool:
    return request.principal_type == PRINCIPAL_AGENT


def principal(request: DecisionRequest) -> RuleResult:
    """Only mensch and agent may request actions; broker and unknown are DENY (S2, F3)."""
    if request.principal_type in (PRINCIPAL_HUMAN, PRINCIPAL_AGENT):
        return RuleResult("principal", Gate.ALLOW, f"principal_type={request.principal_type}")
    return RuleResult("principal", Gate.DENY,
                      f"principal_type={request.principal_type or '<missing>'} may not act",
                      CODE_PRINCIPAL_NOT_ALLOWED)


def halt(request: DecisionRequest, halted: bool) -> RuleResult:
    """Agent requests are DENY while halted; humans are never affected (PM-F30, F33)."""
    if not _is_agent(request):
        return RuleResult("halt", Gate.ALLOW, _NOT_APPLICABLE)
    if halted:
        return RuleResult("halt", Gate.DENY, "agent chain halted", CODE_HALTED)
    return RuleResult("halt", Gate.ALLOW, "not halted")


def evidence(request: DecisionRequest) -> RuleResult:
    """Agent requests need evidence ids (PM-F06, D22). Their origin is checked by the runtime."""
    if not _is_agent(request):
        return RuleResult("beleg", Gate.ALLOW, _NOT_APPLICABLE)
    ids = [i for i in request.evidence_ids if str(i).strip()]
    if not ids:
        return RuleResult("beleg", Gate.DENY, "agent request without beleg_ids", CODE_NO_EVIDENCE)
    return RuleResult("beleg", Gate.ALLOW, f"{len(ids)} beleg_ids")


def _non_empty_list(value: object) -> bool:
    return isinstance(value, list) and any(str(v).strip() for v in value)


def judgement_confidence(judgement: dict) -> float | None:
    """urteil.konfidenz as float in [0, 1], else None. bool is not a number here."""
    value = judgement.get("konfidenz")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = float(value)
    return value if math.isfinite(value) and 0.0 <= value <= 1.0 else None


def judgement(request: DecisionRequest) -> RuleResult:
    """Agent requests carry a complete judgement (PM-F25, D23, F4)."""
    if not _is_agent(request):
        return RuleResult("urteil", Gate.ALLOW, _NOT_APPLICABLE)
    j = request.judgement
    missing = []
    if not str(j.get("empfehlung") or "").strip():
        missing.append("empfehlung")
    if not _non_empty_list(j.get("gegenargumente")):
        missing.append("gegenargumente")
    if not _non_empty_list(j.get("unsicherheiten")):
        missing.append("unsicherheiten")
    if judgement_confidence(j) is None:
        missing.append("konfidenz")
    if missing:
        return RuleResult("urteil", Gate.DENY, "incomplete: " + ", ".join(missing),
                          CODE_INCOMPLETE_JUDGEMENT)
    return RuleResult("urteil", Gate.ALLOW, "complete")


def stage(request: DecisionRequest, min_gates: dict[int, Gate], high_crit_gates: dict[int, Gate],
          criticality: float, threshold: float, default: Gate) -> RuleResult:
    """Minimum gate from the decision-matrix stage 0-4 (PM-F03). Agents only."""
    if not _is_agent(request):
        return RuleResult("stufe", Gate.ALLOW, _NOT_APPLICABLE)
    s = request.stage
    if s is None or s not in min_gates:
        return RuleResult("stufe", default, f"stufe={s} unknown -> default_gate")
    gate, why = min_gates[s], f"stufe={s}"
    if criticality >= threshold and s in high_crit_gates:
        gate = max(gate, high_crit_gates[s])
        why += f", asset_kritikalitaet={criticality:.2f}>={threshold:.2f}"
    return RuleResult("stufe", gate, why)


def irreversible(request: DecisionRequest, reversible: bool) -> RuleResult:
    """Irreversible or loud actions need two persons (PM-F04, D24). Reversibility
    comes from the policy; tipping_off from the caller can only tighten."""
    loud = request.tipping_off.strip().lower() == "laut"
    if not reversible or loud:
        why = "; ".join(w for w, on in (("category irreversible", not reversible),
                                        ("tipping_off=laut", loud)) if on)
        return RuleResult("irreversibel", Gate.APPROVE_2PERSON, why)
    return RuleResult("irreversibel", Gate.ALLOW, "reversible, quiet")


def domain(request: DecisionRequest) -> RuleResult:
    """Unclear or physical domain needs a human (PM-F05). Only cyber does not tighten."""
    d = request.domain.strip().lower()
    if not d and not _is_agent(request):
        return RuleResult("domaene", Gate.ALLOW, _NOT_APPLICABLE)
    if d == "cyber":
        return RuleResult("domaene", Gate.ALLOW, "domaene=cyber")
    return RuleResult("domaene", Gate.APPROVE_1CLICK, f"domaene={d or '<missing>'}")


def resolve_category(request: DecisionRequest, tool_kinds: dict[str, str]) -> tuple[str, str]:
    """Category the policy layer evaluates (SPEC-MCP §3.4, MCP-W01).

    run_playbook keeps the playbook category from the request, as today. For
    every other tool the action kind comes only from the policy; a category sent
    by the caller is ignored. Unmapped tool -> "" -> default_gate (PM-F07).
    """
    if request.kind == RUN_PLAYBOOK:
        return request.category, f"art={RUN_PLAYBOOK}, kategorie={request.category!r}"
    kind = tool_kinds.get(request.kind, "")
    if not kind:
        return "", f"art={request.kind!r} not mapped -> default_gate"
    return kind, f"art={request.kind!r} -> {kind}"


def agent_kind(request: DecisionRequest, category: str, denied_kinds: frozenset[str]) -> RuleResult:
    """Action kinds agents may never request, e.g. entwicklung (SPEC-MCP §3.4)."""
    if not _is_agent(request):
        return RuleResult("aktionsart", Gate.ALLOW, _NOT_APPLICABLE)
    if category in denied_kinds:
        return RuleResult("aktionsart", Gate.DENY, f"{category} not allowed for agents",
                          CODE_NOT_ALLOWED_FOR_AGENT)
    return RuleResult("aktionsart", Gate.ALLOW, f"{category or '<unmapped>'} allowed for agents")
