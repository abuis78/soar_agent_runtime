"""Optional OpenTelemetry export (spec §2 upgrade path).

Zero hard dependency: if ``opentelemetry-sdk`` is not installed, this module is a
clean no-op. Enable via ``TelemetryClient(enable_otel=True)``. The OTLP endpoint
is read by the OTel SDK from ``OTEL_EXPORTER_OTLP_ENDPOINT`` (point it at your
collector, which forwards to Splunk).

Mapping: one span per emitted event. ``llm_call`` events map token counts to the
GenAI SemConv attributes (``gen_ai.usage.input_tokens`` / ``output_tokens`` /
``gen_ai.request.model``); all events also carry flat OCSF fields as attributes.
"""

from __future__ import annotations

import logging

log = logging.getLogger("ai_soc_telemetry.otel")


class OtelExporter:
    """No-op unless opentelemetry is installed and enabled. Never raises to caller."""

    def __init__(self, enabled: bool = False, service_name: str = "ai-soc-telemetry"):
        self._tracer = None
        if not enabled:
            return
        try:
            from opentelemetry import trace
            from opentelemetry.sdk.resources import Resource
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import BatchSpanProcessor
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                OTLPSpanExporter,
            )
        except ImportError:
            log.warning("enable_otel=True but opentelemetry not installed; OTel disabled")
            return

        provider = TracerProvider(resource=Resource.create({"service.name": service_name}))
        provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
        trace.set_tracer_provider(provider)
        self._tracer = trace.get_tracer(service_name)

    @property
    def enabled(self) -> bool:
        return self._tracer is not None

    def record(self, event: dict) -> None:
        """Emit one span for the event. Swallows all errors (fail-open)."""
        if self._tracer is None:
            return
        try:
            name = event.get("event_type", "ai_soc_event")
            with self._tracer.start_as_current_span(name) as span:
                span.set_attribute("event_type", name)
                if (case_id := event.get("case_id")) is not None:
                    span.set_attribute("case_id", case_id)
                if (outcome := event.get("outcome")) is not None:
                    span.set_attribute("outcome", outcome)
                actor = event.get("actor") or {}
                if actor.get("agent_role"):
                    span.set_attribute("actor.agent_role", actor["agent_role"])
                llm = event.get("llm") or {}
                if llm:
                    span.set_attribute("gen_ai.request.model", llm.get("model", ""))
                    span.set_attribute("gen_ai.usage.input_tokens", llm.get("tokens_in", 0))
                    span.set_attribute("gen_ai.usage.output_tokens", llm.get("tokens_out", 0))
        except Exception as e:  # noqa: BLE001 - fail-open
            log.warning("otel record failed: %s", e)
