"""ai-soc-telemetry - thin OCSF-near emit library for the AI-SOC.

Import this from the policy layer, ai-soc-core and the agent runtime. It builds
normalized events and ships them non-blocking / fail-open to Splunk HEC.
"""

from __future__ import annotations

from ai_soc_telemetry import events
from ai_soc_telemetry.client import TelemetryClient
from ai_soc_telemetry.events import (
    agent_action,
    case_lifecycle,
    guardrail_block,
    llm_call,
    policy_decision,
)

__all__ = [
    "TelemetryClient",
    "events",
    "agent_action",
    "case_lifecycle",
    "guardrail_block",
    "llm_call",
    "policy_decision",
]

__version__ = "0.1.0"
