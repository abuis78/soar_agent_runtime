"""OCSF-near event builders.

One flat envelope for everything (see docs/metrics-audit-spec.md §5). Every SOC
component builds events through these helpers so SPL queries can rely on fixed
field names. Rules:
- Fixed field names, portable across SPL.
- Only fill the sub-objects relevant to the given event_type.
- NO untrusted raw text in an event (privacy, L8) - only IDs, categories, numbers.
"""

from __future__ import annotations

Actor = dict  # {"agent_id": str, "agent_role": str}


def policy_decision(
    agent: Actor,
    case_id: str,
    category: str,
    tool: str,
    target: str,
    gate: str,
    risk: float,
    outcome: str,
) -> dict:
    """A policy-layer gate decision (ALLOW / 1CLICK / 2PERSON / DENY)."""
    return {
        "event_type": "policy_decision",
        "actor": agent,
        "case_id": case_id,
        "action": {"category": category, "tool": tool},
        "resource": {"target": target},
        "decision": {"gate": gate, "risk_score": risk},
        "outcome": outcome,
    }


def agent_action(
    agent: Actor,
    case_id: str,
    category: str,
    tool: str,
    target: str,
    outcome: str,
    analyst_override: bool = False,
) -> dict:
    """A response/enrichment action taken by an agent."""
    return {
        "event_type": "agent_action",
        "actor": agent,
        "case_id": case_id,
        "action": {"category": category, "tool": tool},
        "resource": {"target": target},
        "outcome": outcome,
        "analyst_override": analyst_override,
    }


def guardrail_block(
    agent: Actor,
    case_id: str,
    reason: str,
    tool: str | None = None,
) -> dict:
    """A guardrail rejection: sanitize-reject, allowlist-block, kill-switch."""
    return {
        "event_type": "guardrail_block",
        "actor": agent,
        "case_id": case_id,
        "action": {"category": "Guardrail", "tool": tool},
        "decision": {"reason": reason},
        "outcome": "blocked",
    }


def llm_call(
    agent: Actor,
    case_id: str,
    model: str,
    tokens_in: int,
    tokens_out: int,
    latency_ms: int,
) -> dict:
    """A single LLM invocation, for the cost-per-investigation KPI."""
    return {
        "event_type": "llm_call",
        "actor": agent,
        "case_id": case_id,
        "llm": {
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "latency_ms": latency_ms,
        },
        "outcome": "success",
    }


def case_lifecycle(
    case_id: str,
    status: str,
    analyst_touched: int = 0,
    agent: Actor | None = None,
) -> dict:
    """A case state transition (created / ... / resolved) for MTTR & autonomy."""
    event = {
        "event_type": "case_lifecycle",
        "case_id": case_id,
        "status": status,
        "analyst_touched": analyst_touched,
        "outcome": "success",
    }
    if agent is not None:
        event["actor"] = agent
    return event
