"""Non-blocking telemetry client for shipping OCSF-near events to Splunk HEC.

Design contract (see docs/metrics-audit-spec.md §2, §6):
- Fail-open for the business logic: a telemetry failure must NEVER block a SOC
  action. Events are buffered locally and sent asynchronously.
- Fire-and-forget from the caller's perspective; a background worker drains the
  queue and sends to the Splunk HTTP Event Collector (HEC).
"""

from __future__ import annotations

import json
import logging
import os
import queue
import ssl
import threading
import urllib.request

from ai_soc_telemetry.otel import OtelExporter

log = logging.getLogger("ai_soc_telemetry")


class TelemetryClient:
    """Non-blocking emit to Splunk HEC.

    A telemetry error is swallowed (logged, not raised) so the calling SOC
    component is never blocked or crashed by the audit path.
    """

    def __init__(
        self,
        hec_url: str,
        hec_token: str,
        index: str = "ai_soc_audit",
        source: str = "ai-soc",
        max_buffer: int = 10000,
        timeout: float = 5.0,
        verify_tls: bool = True,
        enable_otel: bool = False,
    ) -> None:
        self._url = hec_url
        self._token = hec_token
        self._index = index
        self._source = source
        self._timeout = timeout
        self._otel = OtelExporter(enabled=enable_otel, service_name=source)
        # In production keep verify_tls=True. It is exposed only so a lab/self
        # signed HEC endpoint can be used deliberately, never silently.
        self._ssl_ctx = None if verify_tls else ssl._create_unverified_context()
        self._q: queue.Queue = queue.Queue(maxsize=max_buffer)
        self._worker = threading.Thread(target=self._drain, daemon=True)
        self._worker.start()

    @classmethod
    def from_env(cls, **overrides) -> "TelemetryClient":
        """Build a client from AI_SOC_* environment variables (see .env.example).

        Reads AI_SOC_HEC_URL, AI_SOC_HEC_TOKEN, AI_SOC_INDEX, AI_SOC_ENABLE_OTEL.
        Secrets stay in the environment / .env — never hard-coded (L8). Raises if
        URL or token is missing. `overrides` win over env values.
        """
        url = overrides.pop("hec_url", None) or os.environ.get("AI_SOC_HEC_URL")
        token = overrides.pop("hec_token", None) or os.environ.get("AI_SOC_HEC_TOKEN")
        if not url or not token:
            raise ValueError("AI_SOC_HEC_URL and AI_SOC_HEC_TOKEN must be set")
        index = overrides.pop("index", None) or os.environ.get("AI_SOC_INDEX", "ai_soc_audit")
        enable_otel = overrides.pop(
            "enable_otel",
            os.environ.get("AI_SOC_ENABLE_OTEL", "false").lower() in ("1", "true", "yes"),
        )
        verify_tls = overrides.pop(
            "verify_tls",
            os.environ.get("AI_SOC_VERIFY_TLS", "true").lower() in ("1", "true", "yes"),
        )
        return cls(
            hec_url=url, hec_token=token, index=index,
            enable_otel=enable_otel, verify_tls=verify_tls, **overrides,
        )

    def emit(self, event: dict) -> None:
        """Enqueue an event. Never blocks; drops on a full buffer instead."""
        try:
            self._q.put_nowait(event)
        except queue.Full:  # never block the caller
            log.warning("telemetry buffer full, dropping event")

    def _drain(self) -> None:
        while True:
            event = self._q.get()
            try:
                self._send(event)
            except Exception as e:  # noqa: BLE001 - fail-open on purpose
                log.warning("telemetry send failed: %s", e)
            self._otel.record(event)  # no-op unless enable_otel + opentelemetry present

    def _send(self, event: dict) -> None:
        payload = json.dumps(
            {
                "index": self._index,
                "source": self._source,
                "sourcetype": "_json",
                "event": event,
            }
        ).encode("utf-8")
        req = urllib.request.Request(
            self._url,
            data=payload,
            headers={
                "Authorization": f"Splunk {self._token}",
                "Content-Type": "application/json",
            },
        )
        urllib.request.urlopen(req, timeout=self._timeout, context=self._ssl_ctx).read()
