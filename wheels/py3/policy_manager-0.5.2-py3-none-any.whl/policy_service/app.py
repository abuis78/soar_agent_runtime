"""Policy service logic without network: routing, roles, HTTP status (docs/API.md).

PolicyService.handle() maps one HTTP request to (status, body). The decision
and approval logic is not reimplemented: every known client CN gets its own
EmbeddedPolicyClient with mandatory audit, all sharing the same state files
(approvals and audit are file-locked since P1/P3.3). HTTP and mTLS live in
policy_service.server and only call handle().
"""
from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, field
from importlib import metadata
from typing import Any, Callable

from policy_client.audit import AuditError, AuditLog, admin_event, redact_path
from policy_client.base import (
    CODE_AUDIT_UNAVAILABLE, CODE_UNKNOWN_APPROVAL, ApprovalStatus, DecisionRequest,
)
from policy_client.embedded import EmbeddedPolicyClient, LifecycleStore
from policy_client.halt import HaltFile
from policy_core.model import SEQUENCE

log = logging.getLogger("policy_service")

MAX_BODY = 64 * 1024
ROLES = frozenset({"decide", "approve", "admin", "read"})
PRINCIPALS = frozenset({"mensch", "agent"})
DEFAULT_PRINCIPALS = frozenset({"agent"})   # CN without [principals] entry: strictest rules (F1)
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,128}$")
RESUME = "admin_resume"              # approval kind for lifting a halt (PM-F32)
RESUME_APPROVERS = 2
_APPROVAL_RE = re.compile(r"^/v1/approvals/([^/]+)(?:/(approve|reject|consume))?$")

Response = tuple[int, dict]


@dataclass(frozen=True)
class ServiceConfig:
    policy_path: str
    state_dir: str                       # approvals.json, halt.json, audit.jsonl, sequences.json
    clients: dict[str, frozenset[str]]   # certificate CN -> roles
    ttl: float = 600.0
    # certificate CN -> principal types it may claim; missing CN -> DEFAULT_PRINCIPALS (F1)
    principals: dict[str, frozenset[str]] = field(default_factory=dict)

    def principals_for(self, cn: str) -> frozenset[str]:
        return self.principals.get(cn, DEFAULT_PRINCIPALS)

    @property
    def approvals_path(self) -> str:
        return os.path.join(self.state_dir, "approvals.json")

    @property
    def halt_path(self) -> str:
        return os.path.join(self.state_dir, "halt.json")

    @property
    def audit_path(self) -> str:
        return os.path.join(self.state_dir, "audit.jsonl")

    @property
    def sequences_path(self) -> str:
        return os.path.join(self.state_dir, "sequences.json")


def _error(status: int, code: str, reason: str) -> Response:
    return status, {"code": code, "grund": reason}


def _version() -> str:
    try:
        return metadata.version("policy-manager")
    except metadata.PackageNotFoundError:
        return "0.0.0+source"


class _BadRequest(Exception):
    pass


class PolicyService:
    def __init__(self, config: ServiceConfig) -> None:
        unknown = {r for roles in config.clients.values() for r in roles} - ROLES
        if unknown:
            raise ValueError(f"unknown roles in config: {sorted(unknown)}")
        unknown = {p for ps in config.principals.values() for p in ps} - PRINCIPALS
        if unknown:
            raise ValueError(f"unknown principal types in config: {sorted(unknown)}")
        strangers = set(config.principals) - set(config.clients)
        if strangers:
            raise ValueError(f"principals for unknown clients: {sorted(strangers)}")
        self._cfg = config
        self._clients = {
            cn: EmbeddedPolicyClient(config.policy_path, config.approvals_path, config.halt_path,
                                     ttl=config.ttl, audit_path=config.audit_path,
                                     audit_client=cn, sequences_path=config.sequences_path,
                                     allowed_principals=config.principals_for(cn))
            for cn in config.clients
        }
        # Read-only view for endpoints that do not depend on the caller.
        self._probe = EmbeddedPolicyClient(config.policy_path, config.approvals_path,
                                           config.halt_path, ttl=config.ttl,
                                           sequences_path=config.sequences_path)
        # Halt and resume act on the shared state directly (G6).
        self._store = LifecycleStore(config.approvals_path)
        self._halt_file = HaltFile(config.halt_path)
        self._audit = AuditLog(config.audit_path)

    # --- entry point ---------------------------------------------------------

    def handle(self, method: str, path: str, query: dict[str, list[str]], body: bytes,
               client_cn: str) -> Response:
        try:
            if len(body) > MAX_BODY:
                return _error(413, "TOO_LARGE", f"body larger than {MAX_BODY} bytes")
            if path in ("/health", "/ready", "/version") and method == "GET":
                return self._ops(path)
            if client_cn not in self._clients:
                return _error(403, "FORBIDDEN", "unknown client identity")
            route = self._route(method, path)
            if route is None:
                return _error(404, "NOT_FOUND", f"{method} {path}")
            roles, handler, args = route
            if not roles & self._cfg.clients[client_cn]:
                return _error(403, "FORBIDDEN", f"role required: {' or '.join(sorted(roles))}")
            return handler(client_cn, body, query, *args)
        except _BadRequest as exc:
            return _error(400, "BAD_REQUEST", str(exc))
        except Exception as exc:           # never leak details, never ALLOW
            log.error("[policy_service] %s %s failed: %s", method, redact_path(path),
                      type(exc).__name__)   # message may carry ids (PM-F42)
            return _error(500, "INTERNAL", "internal error")

    def _route(self, method: str, path: str) -> tuple[frozenset, Callable[..., Response], tuple] | None:
        static: dict[tuple[str, str], tuple[frozenset, Callable[..., Response]]] = {
            ("POST", "/v1/decide"): (frozenset({"decide"}), self._decide),
            # Not for the decide (agent) path: no probing of gate limits or patterns (F12).
            ("POST", "/v1/simulate"): (frozenset({"read", "admin"}), self._simulate),
            ("GET", "/v1/halt"): (frozenset({"decide", "read", "admin"}), self._halt),
            ("GET", "/v1/policy"): (frozenset({"read", "admin"}), self._policy),
            ("GET", "/v1/aktionen"): (frozenset({"decide", "read"}), self._actions),
            ("GET", "/v1/approvals"): (frozenset({"read"}), self._pending),
            ("POST", "/v1/admin/halt"): (frozenset({"admin"}), self._admin_halt),
            ("POST", "/v1/admin/resume"): (frozenset({"admin"}), self._admin_resume),
        }
        if (method, path) in static:
            roles, handler = static[(method, path)]
            return roles, handler, ()
        m = _APPROVAL_RE.match(path)
        if not m or not _ID_RE.match(m.group(1)):
            return None
        approval_id, action = m.group(1), m.group(2)
        table = {
            ("GET", None): (frozenset({"decide", "approve", "read"}), self._status),
            ("POST", "approve"): (frozenset({"approve"}), self._approve),
            ("POST", "reject"): (frozenset({"approve"}), self._reject),
            ("POST", "consume"): (frozenset({"decide"}), self._consume),
        }
        if (method, action) not in table:
            return None
        roles, handler = table[(method, action)]
        if action in ("approve", "reject") and self._store.kind(approval_id) == RESUME:
            roles = frozenset({"admin"})       # lifting a halt is an admin decision
        return roles, handler, (approval_id,)

    # --- body parsing --------------------------------------------------------

    @staticmethod
    def _json(body: bytes) -> dict:
        try:
            data = json.loads(body.decode("utf-8")) if body else None
        except (UnicodeDecodeError, ValueError):
            raise _BadRequest("body is not valid JSON") from None
        if not isinstance(data, dict):
            raise _BadRequest("body must be a JSON object")
        return data

    def _request(self, body: bytes) -> DecisionRequest:
        data = self._json(body)
        action = data.get("aktion")
        if not isinstance(action, dict) or not isinstance(action.get("art"), str) \
                or not action["art"].strip():
            raise _BadRequest("aktion.art is required")
        if "kontext" in data and not isinstance(data["kontext"], dict):
            raise _BadRequest("kontext must be an object")
        if action["art"] == SEQUENCE:
            steps = action.get("schritte")
            if not isinstance(steps, list) or not steps or not all(
                    isinstance(s, dict) and isinstance(s.get("baustein"), str)
                    and s["baustein"].strip() for s in steps):
                raise _BadRequest("aktion.schritte must be a non-empty list of steps with baustein")
        return DecisionRequest.from_wire(data)

    def _approver(self, body: bytes) -> str:
        approver = self._json(body).get("freigebender", "")
        if not isinstance(approver, str):
            raise _BadRequest("freigebender must be a string")
        return approver

    # --- handlers ------------------------------------------------------------

    def _decide(self, cn: str, body: bytes, query: dict) -> Response:
        return 200, self._clients[cn].decide(self._request(body)).to_wire()

    def _simulate(self, cn: str, body: bytes, query: dict) -> Response:
        return 200, self._clients[cn].simulate(self._request(body)).to_wire()

    @staticmethod
    def _approval_response(status: Any) -> Response:
        if status.code == CODE_UNKNOWN_APPROVAL:
            return 404, status.to_wire()
        if status.code == CODE_AUDIT_UNAVAILABLE:
            return 503, status.to_wire()
        return 200, status.to_wire()

    def _status(self, cn: str, body: bytes, query: dict,
                approval_id: str) -> Response:
        return self._approval_response(self._clients[cn].approval_status(approval_id))

    def _approve(self, cn: str, body: bytes, query: dict,
                 approval_id: str) -> Response:
        status = self._clients[cn].approve(approval_id, self._approver(body))
        if status.status == "approved" and self._store.kind(approval_id) == RESUME:
            return self._resume(cn, approval_id)
        return self._approval_response(status)

    def _reject(self, cn: str, body: bytes, query: dict,
                approval_id: str) -> Response:
        return self._approval_response(self._clients[cn].reject(approval_id, self._approver(body)))

    def _consume(self, cn: str, body: bytes, query: dict,
                 approval_id: str) -> Response:
        result = self._clients[cn].consume(approval_id, self._request(body))
        return (404 if result.code == CODE_UNKNOWN_APPROVAL else 200), result.to_wire()

    def _halt(self, cn: str, body: bytes, query: dict) -> Response:
        return 200, self._clients[cn].halt_status().to_wire()

    def _policy(self, cn: str, body: bytes, query: dict) -> Response:
        client = self._clients[cn]
        return 200, {"policy_version": client.policy_version, "policy": client.engine.config}

    def _actions(self, cn: str, body: bytes, query: dict) -> Response:
        agent_id = (query.get("agent_id") or [""])[0]
        return 200, {"aktionen": self._clients[cn].actions(agent_id)}

    def _pending(self, cn: str, body: bytes, query: dict) -> Response:
        if query.get("status") != ["pending"]:
            raise _BadRequest("status=pending is required")
        return 200, {"freigaben": self._clients[cn].pending_approvals()}

    # --- halt and resume (PM-F30-F32, G6) ------------------------------------

    def _admin_fields(self, body: bytes, person_key: str) -> tuple[str, str]:
        data = self._json(body)
        reason, person = data.get("grund", ""), data.get(person_key, "")
        if not isinstance(reason, str) or not isinstance(person, str) or not person.strip():
            raise _BadRequest(f"grund (string) and {person_key} (non-empty string) are required")
        return reason, person.strip()

    def _admin_halt(self, cn: str, body: bytes, query: dict) -> Response:
        reason, person = self._admin_fields(body, "ausgeloest_von")
        status = self._halt_file.set(True, reason)       # takes effect even without audit
        try:
            self._audit.write(admin_event("halt", cn, person, reason, True))
        except AuditError:
            log.error("[policy_service] halt is active, but audit failed")
            return 503, {"code": CODE_AUDIT_UNAVAILABLE, "grund": "halt active, audit failed",
                         **status.to_wire()}
        return 200, status.to_wire()

    def _admin_resume(self, cn: str, body: bytes, query: dict) -> Response:
        reason, person = self._admin_fields(body, "beantragt_von")
        current = self._halt_file.status()
        if not current.halted:
            return 200, current.to_wire()
        # principal "mensch": a resume process must survive the halt it is meant to lift.
        token, _ = self._store.open(RESUME, {}, RESUME_APPROVERS, person,
                                    "mensch", self._cfg.ttl)
        try:
            self._audit.write(admin_event("resume_beantragt", cn, person, reason, True, token))
        except AuditError:
            return _error(503, CODE_AUDIT_UNAVAILABLE, "audit not writable")
        return 200, self._store.status(token).to_wire()

    def _resume(self, cn: str, approval_id: str) -> Response:
        """Second admin approval reached: audit, spend the approval, lift the halt."""
        try:
            self._audit.write(admin_event("resume", cn, "", "resume approved", False, approval_id))
        except AuditError:
            self._store.consume(approval_id, RESUME, {}, halted=False)   # spent, halt stays
            return 503, ApprovalStatus(approval_id, "consumed", code=CODE_AUDIT_UNAVAILABLE).to_wire()
        result = self._store.consume(approval_id, RESUME, {}, halted=False)
        if not result.ok:
            return 200, self._store.status(approval_id).to_wire()
        self._halt_file.set(False, "resumed after two-person approval")
        return 200, self._store.status(approval_id).to_wire()

    # --- operations (PM-F60) -------------------------------------------------

    def _not_ready(self) -> list[str]:
        problems = []
        if self._probe.engine.invalid_reason:
            problems.append(f"policy: {self._probe.engine.invalid_reason}")
        for name, path in (("audit", self._cfg.audit_path),
                           ("approvals", self._cfg.approvals_path)):
            target = path if os.path.exists(path) else os.path.dirname(path)
            if not os.access(target, os.W_OK):
                problems.append(f"{name}: not writable")
        return problems

    def _ops(self, path: str) -> Response:
        if path == "/health":
            return 200, {"status": "ok"}
        if path == "/version":
            return 200, {"version": _version(), "policy_version": self._probe.policy_version}
        problems = self._not_ready()
        if problems:
            return 503, {"bereit": False, "gruende": problems}
        return 200, {"bereit": True}
