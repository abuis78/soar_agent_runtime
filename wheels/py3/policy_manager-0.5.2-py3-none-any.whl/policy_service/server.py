"""HTTPS server with mutual TLS in front of PolicyService (P3.6, PM §8).

Standard library only (concept, decision 2). The listening socket is wrapped
without handshake; each handler thread does the TLS handshake with a timeout,
so a slow or silent client cannot block accept(). Client identity is the CN
of the verified client certificate. Request bodies are never logged, approval
ids only as hash (PM-F42).
"""
from __future__ import annotations

import json
import logging
import ssl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

from policy_client.audit import redact_path
from policy_service.app import MAX_BODY, PolicyService
from policy_service.config import ServerConfig

log = logging.getLogger("policy_service.server")

# TLS 1.2: forward secrecy and AEAD only, as recommended by BSI TR-02102-2 (F11).
# TLS 1.3 suites cannot be narrowed with the standard library (set at OpenSSL level).
TLS12_CIPHERS = "ECDHE+AESGCM"
HANDSHAKE_TIMEOUT_S = 5.0
REQUEST_TIMEOUT_S = 10.0


def tls_context(cert: str, key: str, ca: str, crl: str = "") -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.set_ciphers(TLS12_CIPHERS)
    ctx.load_cert_chain(cert, key)
    ctx.load_verify_locations(cafile=ca)
    ctx.verify_mode = ssl.CERT_REQUIRED        # mTLS only (PM §8)
    if crl:
        # Revoked client certificates are refused; an expired CRL fails every
        # handshake (F11). Read at start, a new CRL needs a restart.
        ctx.load_verify_locations(cafile=crl)
        ctx.verify_flags |= ssl.VERIFY_CRL_CHECK_LEAF
    return ctx


def peer_cn(conn: ssl.SSLSocket) -> str:
    """The one CN of the client certificate. None or several -> "" (no identity, 403):
    with two CNs, which one names the client would be a guess (F11)."""
    cert = conn.getpeercert() or {}
    names = [str(value) for rdn in cert.get("subject", ()) for key, value in rdn
             if key == "commonName"]
    return names[0] if len(names) == 1 else ""


class _Handler(BaseHTTPRequestHandler):
    server: "PolicyHTTPServer"
    protocol_version = "HTTP/1.1"
    timeout = REQUEST_TIMEOUT_S

    def setup(self) -> None:
        self.request.settimeout(HANDSHAKE_TIMEOUT_S)
        self.request.do_handshake()          # raises on missing/invalid client cert
        self.request.settimeout(REQUEST_TIMEOUT_S)
        super().setup()

    def log_message(self, format: str, *args) -> None:   # noqa: A002 (stdlib signature)
        log.info("%s %s", self.address_string(), redact_path(format % args))

    def _dispatch(self) -> None:
        url = urlsplit(self.path)
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = -1
        if length < 0:
            status, body = 400, {"code": "BAD_REQUEST", "grund": "invalid Content-Length"}
        elif length > MAX_BODY:
            status, body = 413, {"code": "TOO_LARGE", "grund": f"body larger than {MAX_BODY} bytes"}
            self.close_connection = True          # do not read the oversized body
        else:
            raw = self.rfile.read(length) if length else b""
            status, body = self.server.service.handle(
                self.command, url.path, parse_qs(url.query), raw, peer_cn(self.request))
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        if self.close_connection:
            self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(payload)

    do_GET = _dispatch
    do_POST = _dispatch


class PolicyHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, config: ServerConfig, service: PolicyService) -> None:
        self.service = service
        super().__init__((config.host, config.port), _Handler)
        ctx = tls_context(config.cert, config.key, config.ca, config.crl)
        self.socket = ctx.wrap_socket(self.socket, server_side=True, do_handshake_on_connect=False)

    def handle_error(self, request, client_address) -> None:
        # TLS failures (no or foreign client cert) and timeouts are expected; log one line.
        log.warning("connection from %s dropped", client_address[0] if client_address else "?")


def serve(config: ServerConfig) -> PolicyHTTPServer:
    """Build the server (bound, not yet serving). Call serve_forever() on it."""
    return PolicyHTTPServer(config, PolicyService(config.service))

