"""Start the policy service: python -m policy_service --config <file> [--check] (P3.6)."""
from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import threading

from policy_service.app import PolicyService
from policy_service.config import ServerConfig, load_config
from policy_service.server import PolicyHTTPServer, tls_context


def _check(cfg: ServerConfig) -> list[str]:
    """Problems that would make the service useless; empty list = ready to start."""
    problems = []
    try:
        tls_context(cfg.cert, cfg.key, cfg.ca)
    except (OSError, ValueError) as exc:
        problems.append(f"TLS material: {exc}")
    service = PolicyService(cfg.service)
    status, body = service.handle("GET", "/ready", {}, b"", "")
    if status != 200:
        problems.extend(body.get("gruende", []))
    halt_path = cfg.service.halt_path
    if not os.path.exists(halt_path):
        problems.append(
            f"halt file missing -> agents are halted (E9). Create it with:\n"
            f"    printf '{{\"angehalten\": false, \"grund\": \"eingerichtet\"}}\\n' > {halt_path}\n"
            f"    chmod 644 {halt_path}")
    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m policy_service",
                                     description="Policy Manager service (gate 2), mTLS only.")
    parser.add_argument("--config", required=True, help="service config (TOML)")
    parser.add_argument("--check", action="store_true",
                        help="validate config, TLS material, policy and state, then exit")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

    try:
        cfg = load_config(args.config)
    except ValueError as exc:
        print(f"Config error: {exc}", file=sys.stderr)
        return 2
    problems = _check(cfg)
    if args.check:
        if problems:
            print("Not ready:\n- " + "\n- ".join(problems), file=sys.stderr)
            return 1
        print(f"OK: config, TLS material, policy and state are usable "
              f"({len(cfg.service.clients)} clients).")
        return 0
    for problem in problems:
        logging.warning("not ready: %s", problem)

    server = PolicyHTTPServer(cfg, PolicyService(cfg.service))
    stop = threading.Event()

    def _shutdown(signum, frame) -> None:
        if not stop.is_set():
            stop.set()
            threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)
    logging.info("policy service listening on https://%s:%d (mTLS), %d clients",
                 cfg.host, cfg.port, len(cfg.service.clients))
    try:
        server.serve_forever()
    finally:
        server.server_close()
        logging.info("policy service stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
