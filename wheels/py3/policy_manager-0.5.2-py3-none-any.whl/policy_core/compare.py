"""Compare two policy files and classify every change (P5.3, PM-F51, AC-09, E5, I2).

Structural, not semantic: each change is looser, stricter or neutral by the
table in docs/API.md §9. A change that cannot be classified for sure counts as
looser (fail-closed), so in doubt a policy change needs two reviews. Whether a
looser-classified change really loosens a decision shows the simulation.

    python -m policy_core.compare OLD NEW [REQUESTS.jsonl ...] [--json]

The simulation (PM-F52, I6) replays recorded requests against both policies:
audit lines (ereignis=decide with anfrage) or bare requests {"aktion", "kontext"}.
Not halted, empty sequence register, on both sides alike. A looser result makes
the whole change looser. Output names only the source line, never the request.

Exit 0: nothing looser, 1: something looser, 2: error (file missing, policy invalid).
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from policy_core.engine import PolicyEngine
from policy_core.layer import Gate
from policy_core.model import DecisionRequest

LOOSER, STRICTER, NEUTRAL = "lockernd", "verschaerfend", "neutral"
EXIT_OK, EXIT_LOOSER, EXIT_ERROR = 0, 1, 2

_MISSING = None


@dataclass(frozen=True)
class Change:
    path: str
    old: Any
    new: Any
    kind: str
    note: str = ""

    def to_wire(self) -> dict:
        wire = {"pfad": self.path, "alt": _plain(self.old), "neu": _plain(self.new),
                "einstufung": self.kind}
        if self.note:
            wire["hinweis"] = self.note
        return wire


def _plain(value: Any) -> Any:
    if isinstance(value, (set, frozenset)):
        return sorted(_plain(v) for v in value)
    return value


def _unknown(path: str, old: Any, new: Any) -> list[Change]:
    return [Change(path, old, new, LOOSER, "not classified, counts as looser")]


def _neutral(path: str, old: Any, new: Any) -> list[Change]:
    return [Change(path, old, new, NEUTRAL)]


def _stricter(path: str, old: Any, new: Any) -> list[Change]:
    return [Change(path, old, new, STRICTER)]


def _gate(path: str, old: Any, new: Any) -> list[Change]:
    o, n = Gate.from_name(old), Gate.from_name(new)
    if o == n:
        return [] if old == new else _neutral(path, old, new)
    return [Change(path, old, new, LOOSER if n < o else STRICTER)]


def _number(path: str, old: Any, new: Any, more_is_looser: bool) -> list[Change]:
    try:
        looser = (new > old) if more_is_looser else (new < old)
    except TypeError:
        return _unknown(path, old, new)
    return [Change(path, old, new, LOOSER if looser else STRICTER)]


def _as_set(value: Any) -> Optional[frozenset]:
    if value is _MISSING:
        return frozenset()
    if not isinstance(value, list):
        return None
    try:
        return frozenset(frozenset(v) if isinstance(v, list) else v for v in value)
    except TypeError:
        return None


def _members(path: str, old: Any, new: Any, more_is_stricter: bool) -> list[Change]:
    """Lists as sets: entries added or removed, each with its direction."""
    o, n = _as_set(old), _as_set(new)
    if o is None or n is None:
        return _unknown(path, old, new)
    if o == n:
        return [] if old == new else _neutral(path, old, new)
    changes = []
    if o - n:
        changes.append(Change(path, o - n, _MISSING, LOOSER if more_is_stricter else STRICTER,
                              "removed"))
    if n - o:
        changes.append(Change(path, _MISSING, n - o, STRICTER if more_is_stricter else LOOSER,
                              "added"))
    return changes


def _more_stricter(path: str, old: Any, new: Any) -> list[Change]:
    return _members(path, old, new, more_is_stricter=True)


def _more_looser(path: str, old: Any, new: Any) -> list[Change]:
    return _members(path, old, new, more_is_stricter=False)


def _keys(old: Any, new: Any) -> Optional[list[str]]:
    o = {} if old is _MISSING else old
    n = {} if new is _MISSING else new
    if not isinstance(o, dict) or not isinstance(n, dict):
        return None
    return sorted(set(o) | set(n))


def _get(section: Any, key: str, default: Any = _MISSING) -> Any:
    return section.get(key, default) if isinstance(section, dict) else default


def _each(handler: Callable[[str, Any, Any], list[Change]], default: Any = _MISSING):
    """Handler for a table whose entries all use the same handler."""
    def compare(path: str, old: Any, new: Any) -> list[Change]:
        keys = _keys(old, new)
        if keys is None:
            return _unknown(path, old, new)
        changes = []
        for key in keys:
            o, n = _get(old, key, default), _get(new, key, default)
            if o != n:
                changes += handler(f"{path}.{key}", o, n)
        return changes
    return compare


def _fields(handlers: dict[str, Callable[[str, Any, Any], list[Change]]],
            defaults: Optional[dict[str, Any]] = None):
    """Handler for a table with known keys; unknown keys count as looser."""
    defaults = defaults or {}

    def compare(path: str, old: Any, new: Any) -> list[Change]:
        keys = _keys(old, new)
        if keys is None:
            return _unknown(path, old, new)
        changes = []
        for key in keys:
            o, n = _get(old, key, defaults.get(key)), _get(new, key, defaults.get(key))
            if o != n:
                changes += handlers.get(key, _unknown)(f"{path}.{key}", o, n)
        return changes
    return compare


def _with_default(table: str, default_gate: Callable[[dict], Any]):
    """Gate tables whose missing entries fall back to default_gate (categories, stages)."""
    def compare(path: str, old_cfg: dict, new_cfg: dict) -> list[Change]:
        old, new = old_cfg.get(table, {}), new_cfg.get(table, {})
        keys = _keys(old, new)
        if keys is None:
            return _unknown(path, old, new)
        changes = []
        for key in keys:
            o, n = _get(old, key, default_gate(old_cfg)), _get(new, key, default_gate(new_cfg))
            if _get(old, key) != _get(new, key):
                changes += (_gate(f"{path}.{key}", o, n)
                            or _neutral(f"{path}.{key}", _get(old, key), _get(new, key)))
        return changes
    return compare


def _default_gate(cfg: dict) -> Any:
    return cfg.get("default_gate", "DENY")


def _undo(path: str, old: Any, new: Any) -> list[Change]:
    if not new:
        return [Change(path, old, new, STRICTER, "without undo only alone")]
    return [Change(path, old, new, LOOSER)]


_BLOCK = _fields({
    "version": _stricter,                      # known sequences become new again (H7)
    "purpose": _neutral,
    "agents": _more_looser,
    "min_stage": lambda p, o, n: _number(p, o, n, more_is_looser=False),
    "min_gate": _gate,
    "loud": lambda p, o, n: [Change(p, o, n, LOOSER if o and not n else STRICTER)],
    "reversible": lambda p, o, n: [Change(p, o, n, LOOSER if n and not o else STRICTER)],
    "undo": _undo,
    "blocklist": _more_stricter,
}, defaults={"min_stage": 0, "min_gate": "ALLOW", "undo": "", "agents": [], "blocklist": []})


def _blocks(path: str, old: Any, new: Any) -> list[Change]:
    keys = _keys(old, new)
    if keys is None:
        return _unknown(path, old, new)
    changes = []
    for key in keys:
        o, n = _get(old, key), _get(new, key)
        if o == n:
            continue
        if o is _MISSING:
            changes.append(Change(f"{path}.{key}", o, n, LOOSER, "new building block"))
        elif n is _MISSING:
            changes.append(Change(f"{path}.{key}", o, n, STRICTER, "building block removed"))
        else:
            changes += _BLOCK(f"{path}.{key}", o, n)
    return changes


_TOP: dict[str, Callable[[str, Any, Any], list[Change]]] = {
    "version": _neutral,
    "default_gate": lambda p, o, n: _gate(p, "DENY" if o is _MISSING else o,
                                          "DENY" if n is _MISSING else n),
    "irreversible_categories": _more_stricter,
    "agent_denied_kinds": _more_stricter,
    "stage_min_gate_high_criticality": _each(_gate, default="ALLOW"),
    "always_2person_targets": _fields({"asset_tags": _more_stricter,
                                       "identity_tags": _more_stricter}),
    "asset_context": _fields({"asset_tags": _each(_more_stricter),
                              "identity_tags": _each(_more_stricter)}),
    "sequence_rules": _fields({
        "max_steps": lambda p, o, n: _number(p, o, n, more_is_looser=True),
        "blocked_pairs": _more_stricter,
        "new_sequence_min_gate": _gate,
    }, defaults={"max_steps": 5, "blocked_pairs": [], "new_sequence_min_gate": "APPROVE_1CLICK"}),
    "building_blocks": _blocks,
}

# Need the whole config: missing entries fall back to the side's default_gate.
_TOP_WITH_DEFAULT = {
    "categories": _with_default("categories", _default_gate),
    "stage_min_gate": _with_default("stage_min_gate", _default_gate),
}


def compare_policies(old: dict, new: dict) -> list[Change]:
    """Every change between two policy configs, classified (docs/API.md §9)."""
    changes: list[Change] = []
    for key in sorted(set(old) | set(new)):
        if key in _TOP_WITH_DEFAULT:
            changes += _TOP_WITH_DEFAULT[key](key, old, new)
            continue
        o, n = old.get(key, _MISSING), new.get(key, _MISSING)
        if o != n:
            # "_..." keys are the comments of JSON policies; the engine never reads them.
            handler = _neutral if key.startswith("_") else _TOP.get(key, _unknown)
            changes += handler(key, o, n)
    return changes


@dataclass(frozen=True)
class Replay:
    """A recorded request whose result differs between the two policies."""
    source: str                      # file:line
    decision_id: str
    old: tuple[str, str]             # gate name, code
    new: tuple[str, str]
    kind: str

    def to_wire(self) -> dict:
        wire = {"quelle": self.source, "einstufung": self.kind,
                "alt": {"gate": self.old[0], "code": self.old[1]},
                "neu": {"gate": self.new[0], "code": self.new[1]}}
        if self.decision_id:
            wire["entscheidung_id"] = self.decision_id
        return wire


@dataclass
class Simulation:
    replayed: int = 0
    skipped: int = 0
    unusable: list[str] = field(default_factory=list)
    changed: list[Replay] = field(default_factory=list)

    def to_wire(self) -> dict:
        return {"abgespielt": self.replayed, "uebersprungen": self.skipped,
                "unbrauchbar": self.unusable, "geaendert": [r.to_wire() for r in self.changed]}


_OK, _SKIP, _BAD = "ok", "skip", "bad"


def _parse(line: str) -> tuple[str, Optional[DecisionRequest], str]:
    """(status, request, entscheidung_id) for one JSONL line."""
    try:
        data = json.loads(line)
    except ValueError:
        return _BAD, None, ""
    if not isinstance(data, dict):
        return _BAD, None, ""
    decision_id = ""
    if "ereignis" in data:                                   # audit line
        if data.get("ereignis") != "decide" or "anfrage" not in data:
            return _SKIP, None, ""
        decision_id = str(data.get("entscheidung_id") or "")
        data = data["anfrage"]
        if not isinstance(data, dict):
            return _BAD, None, decision_id
    action = data.get("aktion")
    if not isinstance(action, dict) or not isinstance(action.get("art"), str) \
            or not action["art"].strip():
        return _BAD, None, decision_id
    return _OK, DecisionRequest.from_wire(data), decision_id


def simulate(old: PolicyEngine, new: PolicyEngine, paths: list[str]) -> Simulation:
    """Replay every request in the JSONL files. Raises OSError/ValueError if a file is unreadable."""
    sim = Simulation()
    for path in paths:
        with open(path, encoding="utf-8") as fh:
            for number, line in enumerate(fh, start=1):
                if not line.strip():
                    continue
                status, request, decision_id = _parse(line)
                if status == _SKIP:
                    sim.skipped += 1
                    continue
                if status == _BAD:
                    sim.unusable.append(f"{path}:{number}")
                    continue
                sim.replayed += 1
                a = old.evaluate(request, False, sequence_known=False)
                b = new.evaluate(request, False, sequence_known=False)
                if (a.gate, a.code) == (b.gate, b.code):
                    continue
                kind = LOOSER if b.gate < a.gate else STRICTER if b.gate > a.gate else NEUTRAL
                sim.changed.append(Replay(f"{path}:{number}", decision_id,
                                          (a.gate.name, a.code), (b.gate.name, b.code), kind))
    return sim


def overall(items: list) -> str:
    """Overall result of policy changes and replays (anything with a kind)."""
    kinds = {i.kind for i in items}
    return LOOSER if LOOSER in kinds else STRICTER if STRICTER in kinds else NEUTRAL


def _load(path: str) -> PolicyEngine:
    engine = PolicyEngine(path)
    if engine.invalid_reason:
        raise ValueError(f"{path}: {engine.invalid_reason}")
    return engine


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m policy_core.compare",
        description="Classify the changes between two policy files (docs/API.md §9).")
    parser.add_argument("old", help="policy file before the change")
    parser.add_argument("new", help="policy file after the change")
    parser.add_argument("requests", nargs="*",
                        help="JSONL files with recorded requests (audit or bare requests)")
    parser.add_argument("--json", action="store_true", help="print one JSON object")
    args = parser.parse_args(argv)
    try:
        old, new = _load(args.old), _load(args.new)
        sim = simulate(old, new, args.requests) if args.requests else None
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_ERROR

    changes = compare_policies(old.config, new.config)
    result = overall(changes + (sim.changed if sim else []))
    if args.json:
        out = {"ergebnis": result, "aenderungen": [c.to_wire() for c in changes]}
        if sim:
            out["simulation"] = sim.to_wire()
        print(json.dumps(out, ensure_ascii=False, sort_keys=True))
    else:
        for c in changes:
            note = f"  ({c.note})" if c.note else ""
            print(f"{c.kind:<14} {c.path}: {_plain(c.old)!r} -> {_plain(c.new)!r}{note}")
        if sim:
            for r in sim.changed:
                ref = f" ({r.decision_id})" if r.decision_id else ""
                old_result, new_result = (" ".join(filter(None, x)) for x in (r.old, r.new))
                print(f"{r.kind:<14} {r.source}{ref}: {old_result} -> {new_result}")
            print(f"Simulation: {sim.replayed} replayed, {len(sim.changed)} changed, "
                  f"{sim.skipped} skipped, {len(sim.unusable)} unusable"
                  + (f" ({', '.join(sim.unusable)})" if sim.unusable else ""))
        print(f"Result: {result} ({len(changes)} changes)")
    return EXIT_LOOSER if result == LOOSER else EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
