"""Policy Manager decision core: pure functions, no network or SOAR access (PM-N01)."""
