"""Rules for sequences of building blocks (P4.4, PM-F10-F12, H3-H7).

Pure functions like policy_core.rules. They run before the steps are evaluated
(PM-F10). Each returns RuleResults; the step index, where there is one, is
returned alongside so the engine can put it into the reasons ("schritt").
"""
from __future__ import annotations

import hashlib
import json
from typing import Callable, Optional

from policy_core.catalog import BuildingBlock, Catalog
from policy_core.layer import Gate
from policy_core.model import (
    CODE_BLOCK_NOT_ALLOWED, CODE_INVALID_SEQUENCE, PRINCIPAL_AGENT, SEQUENCE, DecisionRequest,
)
from policy_core.rules import RuleResult

Indexed = tuple[Optional[int], RuleResult]


def blocks_of(request: DecisionRequest, catalog: Catalog) -> list[Optional[BuildingBlock]]:
    """Building block per step; None for an unknown or missing one."""
    return [catalog.blocks.get(step.block) if step.block else None for step in request.steps]


def catalog_check(request: DecisionRequest, catalog: Catalog) -> list[Indexed]:
    """Unknown block; for agents also: not released for agent_id, stage below min_stage (H6)."""
    agent = request.principal_type == PRINCIPAL_AGENT
    results: list[Indexed] = []
    for i, (step, block) in enumerate(zip(request.steps, blocks_of(request, catalog))):
        problems = []
        if block is None:
            problems.append(f"baustein={step.block or '<missing>'!s} not in catalogue")
        elif agent:
            if request.agent_id not in block.agents:
                problems.append(f"{block.id} not released for agent_id="
                                f"{request.agent_id or '<missing>'}")
            if block.min_stage > 0 and (request.stage is None or request.stage < block.min_stage):
                problems.append(f"{block.id} needs stufe>={block.min_stage}, got {request.stage}")
        if problems:
            results.append((i, RuleResult("katalog", Gate.DENY, "; ".join(problems),
                                          CODE_BLOCK_NOT_ALLOWED)))
        else:
            why = f"{block.id} v{block.version}" + ("" if agent else " (mensch)")
            results.append((i, RuleResult("katalog", Gate.ALLOW, why)))
    return results


def combination_check(request: DecisionRequest, catalog: Catalog,
                      tags_of: Callable[[tuple[str, ...]], set[str]]) -> list[Indexed]:
    """Combination rules (PM-F10): max steps, blocked pairs, no undo only alone, blocklists."""
    rules = catalog.rules
    blocks = blocks_of(request, catalog)
    known = [b for b in blocks if b is not None]
    results: list[Indexed] = []

    def deny(why: str, index: Optional[int] = None) -> None:
        results.append((index, RuleResult("kombination", Gate.DENY, why, CODE_INVALID_SEQUENCE)))

    if len(request.steps) > rules.max_steps:
        deny(f"{len(request.steps)} steps > max_steps={rules.max_steps}")
    ids = {b.id for b in known}
    for pair in sorted(rules.blocked_pairs, key=sorted):
        if pair <= ids:
            deny("blocked pair " + " + ".join(sorted(pair)))
    if len(request.steps) > 1:
        for i, block in enumerate(blocks):
            if block is not None and not block.undo:
                deny(f"{block.id} has no undo, only allowed as a single step", i)
    for i, (step, block) in enumerate(zip(request.steps, blocks)):
        if block is None or not block.blocklist:
            continue
        hits = (set(step.targets) | tags_of(step.targets)) & block.blocklist
        if hits:
            deny(f"{block.id}: target on blocklist ({', '.join(sorted(hits))})", i)
    if not results:
        results.append((None, RuleResult("kombination", Gate.ALLOW,
                                          f"{len(request.steps)} steps, no rule violated")))
    return results


def new_sequence(request: DecisionRequest, catalog: Catalog, known: bool) -> RuleResult:
    """A sequence of two or more steps never approved before: at least 1-click (PM-F11)."""
    if len(request.steps) < 2:
        return RuleResult("neue_folge", Gate.ALLOW, "single step")
    if known:
        return RuleResult("neue_folge", Gate.ALLOW, "sequence in register")
    gate = catalog.rules.new_sequence_min_gate
    return RuleResult("neue_folge", gate, "sequence not in register")


def min_gate(block: BuildingBlock) -> RuleResult:
    """Minimum gate of the building block (PM-F12)."""
    return RuleResult("mindest_gate", block.min_gate, f"{block.id}.min_gate={block.min_gate.name}")


def sequence_hash(request: DecisionRequest, catalog: Catalog) -> str:
    """Register key (PM-F11): SHA-256 over [[block, version], ...] in order.
    "" for single actions, single steps and sequences with an unknown block."""
    blocks = blocks_of(request, catalog)
    if request.kind != SEQUENCE or len(blocks) < 2 or any(b is None for b in blocks):
        return ""
    key = json.dumps([[b.id, b.version] for b in blocks if b is not None], separators=(",", ":"))
    return hashlib.sha256(key.encode("utf-8")).hexdigest()
