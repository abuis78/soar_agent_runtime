"""Request model shared by the decision core and the client (P2.1).

DecisionRequest lives in policy_core so the engine does not depend on
policy_client; policy_client.base re-exports it under the same name. Python
names are English; to_wire/from_wire use the spec names from
spec-policy-manager.md §5.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

# Codes for DENY decisions from the decision rules (PM §9).
CODE_NO_EVIDENCE = "NO_EVIDENCE"
CODE_INCOMPLETE_JUDGEMENT = "INCOMPLETE_JUDGEMENT"
CODE_HALTED = "HALTED"
CODE_INVALID_SEQUENCE = "INVALID_SEQUENCE"
CODE_PRINCIPAL_NOT_ALLOWED = "PRINCIPAL_NOT_ALLOWED"
CODE_NOT_ALLOWED_FOR_AGENT = "NOT_ALLOWED_FOR_AGENT"
CODE_POLICY_INVALID = "POLICY_INVALID"
CODE_BLOCK_NOT_ALLOWED = "BLOCK_NOT_ALLOWED"

PRINCIPAL_HUMAN = "mensch"
PRINCIPAL_AGENT = "agent"

SEQUENCE = "folge"          # aktion.art of a sequence of building blocks (P4, H1)


def _str_list(value: Any) -> list[str]:
    if not isinstance(value, (list, tuple)):
        return []
    return [str(v) for v in value]


def _opt_float(value: Any) -> Optional[float]:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def _opt_int(value: Any) -> Optional[int]:
    try:
        return None if value is None else int(value)
    except (TypeError, ValueError):
        return None


@dataclass(frozen=True)
class Step:
    """One step of a sequence: a building block from the catalogue (aktion.schritte[])."""
    block: str                                  # baustein
    targets: tuple[str, ...] = ()               # ziel
    params: dict = field(default_factory=dict)  # parameter

    def to_wire(self) -> dict:
        return {"baustein": self.block, "ziel": list(self.targets), "parameter": dict(self.params)}

    @classmethod
    def from_wire(cls, data: Any) -> "Step":
        """A malformed step becomes a step without building block (never permissive)."""
        data = data if isinstance(data, dict) else {}
        block, params = data.get("baustein"), data.get("parameter")
        return cls(block=block if isinstance(block, str) else "",
                   targets=tuple(_str_list(data.get("ziel"))),
                   params=params if isinstance(params, dict) else {})


@dataclass(frozen=True)
class DecisionRequest:
    """An action to be decided, plus the caller's context (PM §5 request)."""
    kind: str                                   # aktion.art, e.g. run_playbook
    category: str = ""                          # aktion.kategorie
    playbook: str = ""                          # aktion.playbook
    targets: tuple[str, ...] = ()               # aktion.ziel
    params: dict = field(default_factory=dict)  # aktion.parameter
    principal_type: str = ""                    # mensch | agent | broker (MCP-G01)
    initiator: str = ""                         # token identity or agent_id (MCP-W04)
    agent_id: str = ""
    run_id: str = ""                            # lauf_id
    step_id: str = ""                           # schritt_id
    stage: Optional[int] = None                 # stufe 0-4, None = not given
    domain: str = ""                            # domaene
    tipping_off: str = ""                       # laut | leise
    confidence: Optional[float] = None          # agent_konfidenz (human path only, MCP-W05)
    evidence_ids: tuple[str, ...] = ()          # beleg_ids
    judgement: dict = field(default_factory=dict)  # urteil
    artifact_values: tuple[str, ...] = ()       # artefakt_werte (MCP-W03)
    steps: tuple[Step, ...] = ()                # aktion.schritte, only for kind == "folge"

    def to_wire(self) -> dict:
        action = {"art": self.kind, "kategorie": self.category, "playbook": self.playbook,
                  "ziel": list(self.targets), "parameter": dict(self.params)}
        if self.steps:
            action["schritte"] = [s.to_wire() for s in self.steps]
        context: dict[str, Any] = {
            "principal_type": self.principal_type, "initiator": self.initiator,
            "agent_id": self.agent_id, "lauf_id": self.run_id, "schritt_id": self.step_id,
            "domaene": self.domain, "tipping_off": self.tipping_off,
            "beleg_ids": list(self.evidence_ids), "urteil": dict(self.judgement),
            "artefakt_werte": list(self.artifact_values),
        }
        if self.stage is not None:
            context["stufe"] = self.stage
        if self.confidence is not None:
            context["agent_konfidenz"] = self.confidence
        return {"aktion": action, "kontext": context}

    @classmethod
    def from_wire(cls, data: Any) -> "DecisionRequest":
        """Parse a wire request. Malformed parts become empty values, which the
        decision rules treat as unknown (never as permissive)."""
        data = data if isinstance(data, dict) else {}
        action = data.get("aktion") if isinstance(data.get("aktion"), dict) else {}
        context = data.get("kontext") if isinstance(data.get("kontext"), dict) else {}
        params = action.get("parameter")
        judgement = context.get("urteil")
        kind = str(action.get("art") or "")
        steps = action.get("schritte") if kind == SEQUENCE else None
        return cls(
            kind=kind,
            category=str(action.get("kategorie") or ""),
            playbook=str(action.get("playbook") or ""),
            targets=tuple(_str_list(action.get("ziel"))),
            params=params if isinstance(params, dict) else {},
            principal_type=str(context.get("principal_type") or ""),
            initiator=str(context.get("initiator") or ""),
            agent_id=str(context.get("agent_id") or ""),
            run_id=str(context.get("lauf_id") or ""),
            step_id=str(context.get("schritt_id") or ""),
            stage=_opt_int(context.get("stufe")),
            domain=str(context.get("domaene") or ""),
            tipping_off=str(context.get("tipping_off") or ""),
            confidence=_opt_float(context.get("agent_konfidenz")),
            evidence_ids=tuple(_str_list(context.get("beleg_ids"))),
            judgement=judgement if isinstance(judgement, dict) else {},
            artifact_values=tuple(_str_list(context.get("artefakt_werte"))),
            steps=tuple(Step.from_wire(s) for s in steps) if isinstance(steps, list) else (),
        )
