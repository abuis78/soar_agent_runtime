"""Action catalogue and sequence rules from the policy file (P4.2, PM-F10, PM-F12).

Optional sections in the same policy file (keys in English, H2/S8):

  [sequence_rules]
  max_steps = 5                              # default 5
  blocked_pairs = [["a", "b"]]               # dangerous pairs, any order
  new_sequence_min_gate = "APPROVE_1CLICK"   # PM-F11; never below APPROVE_1CLICK

  [building_blocks.<id>]
  version = 2                    # required
  category = "Isolation"         # required, evaluated like a playbook category
  loud = true                    # required (laut/leise, PM-F04)
  reversible = true              # required; the policy can still make it irreversible (H4)
  undo = "<id>"                  # undo counterpart; without it: only as a single step
  playbook, purpose, domain, target_types, parameters, min_stage, min_gate, blocklist
  agents = ["<agent_id>"]        # released for these agents only (H3); default none

Anything malformed raises CatalogError, which the engine turns into POLICY_INVALID.
Unknown keys and unknown ids are errors too: a typo must not switch a rule off.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from policy_core.layer import Gate

_STAGES = range(0, 5)
_MAX_STEPS_DEFAULT = 5
_BLOCK_KEYS = frozenset({
    "version", "category", "loud", "reversible", "undo", "playbook", "purpose", "domain",
    "target_types", "parameters", "min_stage", "min_gate", "blocklist", "agents",
})
_RULE_KEYS = frozenset({"max_steps", "blocked_pairs", "new_sequence_min_gate"})


class CatalogError(ValueError):
    pass


@dataclass(frozen=True)
class BuildingBlock:
    id: str
    version: int
    category: str
    loud: bool
    reversible: bool
    undo: str = ""
    playbook: str = ""
    purpose: str = ""
    domain: str = ""
    target_types: tuple[str, ...] = ()
    parameters: dict = field(default_factory=dict)
    min_stage: int = 0
    min_gate: Gate = Gate.ALLOW
    blocklist: frozenset[str] = frozenset()
    agents: frozenset[str] = frozenset()


@dataclass(frozen=True)
class SequenceRules:
    max_steps: int = _MAX_STEPS_DEFAULT
    blocked_pairs: frozenset[frozenset[str]] = frozenset()
    new_sequence_min_gate: Gate = Gate.APPROVE_1CLICK


@dataclass(frozen=True)
class Catalog:
    blocks: dict[str, BuildingBlock] = field(default_factory=dict)
    rules: SequenceRules = SequenceRules()


def _gate(value: Any, where: str) -> Gate:
    if not isinstance(value, str) or value not in Gate.__members__:
        raise CatalogError(f"{where}: unknown gate {value!r}")
    return Gate[value]


def _int(value: Any, where: str, allowed: range) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value not in allowed:
        raise CatalogError(f"{where} must be a whole number in {allowed.start}..{allowed.stop - 1}")
    return value


def _bool(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise CatalogError(f"{where} must be true or false")
    return value


def _str(value: Any, where: str) -> str:
    if not isinstance(value, str):
        raise CatalogError(f"{where} must be a string")
    return value


def _str_list(value: Any, where: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(v, str) and v for v in value):
        raise CatalogError(f"{where} must be a list of non-empty strings")
    return tuple(value)


def _block(block_id: str, raw: Any) -> BuildingBlock:
    where = f"building_blocks.{block_id}"
    if not isinstance(raw, dict):
        raise CatalogError(f"{where} must be a table")
    unknown = set(raw) - _BLOCK_KEYS
    if unknown:
        raise CatalogError(f"{where}: unknown keys {sorted(unknown)}")
    for key in ("version", "category", "loud", "reversible"):
        if key not in raw:
            raise CatalogError(f"{where}.{key} is required")
    category = _str(raw["category"], f"{where}.category")
    if not category.strip():
        raise CatalogError(f"{where}.category must not be empty")
    parameters = raw.get("parameters", {})
    if not isinstance(parameters, dict):
        raise CatalogError(f"{where}.parameters must be a table")
    return BuildingBlock(
        id=block_id,
        version=_int(raw["version"], f"{where}.version", range(1, 2**31)),
        category=category,
        loud=_bool(raw["loud"], f"{where}.loud"),
        reversible=_bool(raw["reversible"], f"{where}.reversible"),
        undo=_str(raw.get("undo", ""), f"{where}.undo"),
        playbook=_str(raw.get("playbook", block_id), f"{where}.playbook"),
        purpose=_str(raw.get("purpose", ""), f"{where}.purpose"),
        domain=_str(raw.get("domain", ""), f"{where}.domain"),
        target_types=_str_list(raw.get("target_types", []), f"{where}.target_types"),
        parameters=dict(parameters),
        min_stage=_int(raw.get("min_stage", 0), f"{where}.min_stage", _STAGES),
        min_gate=_gate(raw.get("min_gate", "ALLOW"), f"{where}.min_gate"),
        blocklist=frozenset(_str_list(raw.get("blocklist", []), f"{where}.blocklist")),
        agents=frozenset(_str_list(raw.get("agents", []), f"{where}.agents")),
    )


def _rules(raw: Any, blocks: dict[str, BuildingBlock]) -> SequenceRules:
    if not isinstance(raw, dict):
        raise CatalogError("sequence_rules must be a table")
    unknown = set(raw) - _RULE_KEYS
    if unknown:
        raise CatalogError(f"sequence_rules: unknown keys {sorted(unknown)}")
    pairs = raw.get("blocked_pairs", [])
    if not isinstance(pairs, list):
        raise CatalogError("sequence_rules.blocked_pairs must be a list of pairs")
    blocked = set()
    for pair in pairs:
        if not isinstance(pair, list) or len(pair) != 2 or not all(isinstance(p, str) for p in pair):
            raise CatalogError(f"sequence_rules.blocked_pairs: {pair!r} is not a pair of ids")
        missing = [p for p in pair if p not in blocks]
        if missing:
            raise CatalogError(f"sequence_rules.blocked_pairs: unknown building blocks {missing}")
        blocked.add(frozenset(pair))
    min_gate = _gate(raw.get("new_sequence_min_gate", "APPROVE_1CLICK"),
                     "sequence_rules.new_sequence_min_gate")
    if min_gate < Gate.APPROVE_1CLICK:
        raise CatalogError("sequence_rules.new_sequence_min_gate must be at least APPROVE_1CLICK")
    return SequenceRules(
        max_steps=_int(raw.get("max_steps", _MAX_STEPS_DEFAULT), "sequence_rules.max_steps",
                       range(1, 1000)),
        blocked_pairs=frozenset(blocked),
        new_sequence_min_gate=min_gate,
    )


def load_catalog(cfg: dict) -> Catalog:
    """Read [building_blocks] and [sequence_rules]; both optional. Raises CatalogError."""
    raw_blocks = cfg.get("building_blocks", {})
    if not isinstance(raw_blocks, dict):
        raise CatalogError("building_blocks must be a table of building blocks")
    blocks = {block_id: _block(block_id, raw) for block_id, raw in raw_blocks.items()}
    for block in blocks.values():
        if block.undo and block.undo not in blocks:
            raise CatalogError(f"building_blocks.{block.id}.undo: unknown building block "
                               f"{block.undo!r}")
    return Catalog(blocks=blocks, rules=_rules(cfg.get("sequence_rules", {}), blocks))
