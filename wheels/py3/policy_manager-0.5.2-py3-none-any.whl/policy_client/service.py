"""Service mode: the decision runs in the policy service (P3.7, MCP-G02, RT-W01).

ServicePolicyClient talks HTTPS with mutual TLS to the service (docs/API.md).
Fail-closed (MCP-G04, RT-W04): unreachable, timeout, TLS error, unexpected
status or malformed answer -> DENY / not valid / halted. No retry and no
fallback to embedded logic. Never raises.
"""
from __future__ import annotations

import http.client
import json
import logging
import ssl
from typing import Any, Optional
from urllib.parse import quote, urlencode, urlsplit

from policy_client.audit import redact_path
from policy_client.base import (
    CODE_AUDIT_UNAVAILABLE, CODE_UNAVAILABLE, ApprovalStatus, ConsumeResult, Decision,
    DecisionRequest, HaltStatus, PolicyClient,
)

log = logging.getLogger("policy_client.service")

_TIMEOUT_DEFAULT = 5.0


class _Unavailable(Exception):
    pass


class ServicePolicyClient(PolicyClient):
    def __init__(self, url: str, cert: str, key: str, ca: str,
                 timeout_s: float = _TIMEOUT_DEFAULT) -> None:
        parts = urlsplit(url)
        self._host = parts.hostname or ""
        self._port = parts.port or 443
        self._base = parts.path.rstrip("/")
        self._timeout = timeout_s
        self._setup_error = "" if parts.scheme == "https" and self._host else "url must be https://host[:port]"
        self._ctx: Optional[ssl.SSLContext] = None
        if not self._setup_error:
            try:
                ctx = ssl.create_default_context(cafile=ca)   # verifies host name and chain
                ctx.minimum_version = ssl.TLSVersion.TLSv1_2
                ctx.load_cert_chain(cert, key)
                self._ctx = ctx
            except (OSError, ValueError, ssl.SSLError) as exc:
                self._setup_error = f"TLS setup failed ({type(exc).__name__})"
        if self._setup_error:
            log.error("[policy_client] service client unusable: %s", self._setup_error)

    # --- transport -----------------------------------------------------------

    def _call(self, method: str, path: str, body: Optional[dict] = None) -> tuple[int, Any]:
        """(status, decoded JSON) or _Unavailable. No retry."""
        if self._ctx is None:
            raise _Unavailable(self._setup_error)
        payload = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Content-Type": "application/json"} if payload is not None else {}
        conn = http.client.HTTPSConnection(self._host, self._port, context=self._ctx,
                                           timeout=self._timeout)
        try:
            conn.request(method, self._base + path, body=payload, headers=headers)
            resp = conn.getresponse()
            raw = resp.read()
        except (OSError, http.client.HTTPException) as exc:   # incl. timeout and TLS errors
            raise _Unavailable(f"{method} {redact_path(path)}: {type(exc).__name__}") from None
        finally:
            conn.close()
        try:
            return resp.status, json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise _Unavailable(f"{method} {redact_path(path)}: HTTP {resp.status}, "
                               "body not JSON") from None

    @staticmethod
    def _approval_path(approval_id: str, action: str = "") -> str:
        return "/v1/approvals/" + quote(str(approval_id), safe="") + (f"/{action}" if action else "")

    # --- PolicyClient ----------------------------------------------------------

    def _decision(self, path: str, request: DecisionRequest) -> Decision:
        try:
            status, data = self._call("POST", path, request.to_wire())
        except _Unavailable as exc:
            log.error("[policy_client] %s -> DENY", exc)
            return Decision.deny(CODE_UNAVAILABLE, str(exc))
        if status != 200:
            return Decision.deny(CODE_UNAVAILABLE, f"policy service answered HTTP {status}")
        return Decision.from_wire(data)

    def decide(self, request: DecisionRequest) -> Decision:
        return self._decision("/v1/decide", request)

    def simulate(self, request: DecisionRequest) -> Decision:
        return self._decision("/v1/simulate", request)

    def _approval(self, approval_id: str, method: str, action: str = "",
                  body: Optional[dict] = None) -> ApprovalStatus:
        try:
            status, data = self._call(method, self._approval_path(approval_id, action), body)
        except _Unavailable as exc:
            log.error("[policy_client] %s", exc)
            return ApprovalStatus(approval_id, "expired", code=CODE_UNAVAILABLE)
        if status in (200, 404):
            return ApprovalStatus.from_wire(data)
        code = CODE_AUDIT_UNAVAILABLE if status == 503 else CODE_UNAVAILABLE
        return ApprovalStatus(approval_id, "expired", code=code)

    def approve(self, approval_id: str, approver: str) -> ApprovalStatus:
        return self._approval(approval_id, "POST", "approve", {"freigebender": approver})

    def reject(self, approval_id: str, approver: str) -> ApprovalStatus:
        return self._approval(approval_id, "POST", "reject", {"freigebender": approver})

    def approval_status(self, approval_id: str) -> ApprovalStatus:
        return self._approval(approval_id, "GET")

    def consume(self, approval_id: str, request: DecisionRequest) -> ConsumeResult:
        try:
            status, data = self._call("POST", self._approval_path(approval_id, "consume"),
                                      request.to_wire())
        except _Unavailable as exc:
            log.error("[policy_client] %s", exc)
            return ConsumeResult(False, CODE_UNAVAILABLE)
        result = ConsumeResult.from_wire(data)          # ok only on "gueltig": true
        return result if status == 200 else ConsumeResult(False, result.code or CODE_UNAVAILABLE)

    def halt_status(self) -> HaltStatus:
        try:
            status, data = self._call("GET", "/v1/halt")
        except _Unavailable as exc:
            return HaltStatus(halted=True, reason=f"halt state unknown ({exc})", known=False)
        if status != 200:
            return HaltStatus(halted=True, reason=f"halt state unknown (HTTP {status})", known=False)
        return HaltStatus.from_wire(data)

    def actions(self, agent_id: str) -> list[dict]:
        try:
            status, data = self._call("GET", "/v1/aktionen?" + urlencode({"agent_id": agent_id}))
        except _Unavailable:
            return []
        items = data.get("aktionen") if status == 200 and isinstance(data, dict) else None
        return [a for a in items if isinstance(a, dict)] if isinstance(items, list) else []

    def pending_approvals(self) -> list[dict]:
        try:
            status, data = self._call("GET", "/v1/approvals?status=pending")
        except _Unavailable:
            return []
        items = data.get("freigaben") if status == 200 and isinstance(data, dict) else None
        return [a for a in items if isinstance(a, dict)] if isinstance(items, list) else []
