"""Emergency stop for embedded mode: a halt file owned by the management domain (E9, W12).

The file holds the HaltStatus wire format, e.g. {"angehalten": false, "grund": "..."}.
Fail-safe (D25, PM-F31): a missing, unreadable or malformed file means halted, and
so does a file someone other than the management domain could change (F13): a
symlink, not a regular file, group- or world-writable, or file or directory owned
by anyone but root or the reading process. Only an explicit "angehalten": false
from a trusted file lets agent runs proceed.
The file is re-read on every call so a halt takes effect immediately.
"""
from __future__ import annotations

import errno
import json
import os
import stat
import tempfile

from policy_client.base import HaltStatus


class HaltFile:
    def __init__(self, path: str) -> None:
        self._path = path

    def status(self) -> HaltStatus:
        try:
            # No symlink; O_NONBLOCK so a FIFO cannot hang the check.
            fd = os.open(self._path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except FileNotFoundError:
            return HaltStatus(halted=True, reason="halt file missing", known=False)
        except OSError as exc:
            reason = "halt file is a symlink" if exc.errno == errno.ELOOP else "halt file unreadable"
            return HaltStatus(halted=True, reason=reason, known=False)
        try:
            with os.fdopen(fd, "rb") as fh:
                problem = self._untrusted(os.fstat(fh.fileno()))   # the file we read, no race
                if problem:
                    return HaltStatus(halted=True, reason=problem, known=False)
                data = json.loads(fh.read().decode("utf-8"))
        except (OSError, ValueError):
            return HaltStatus(halted=True, reason="halt file unreadable", known=False)
        return HaltStatus.from_wire(data)

    def _untrusted(self, st: os.stat_result) -> str:
        """Why the file cannot be trusted to lift a halt, or "" (F13, PM-F31)."""
        trusted = (0, os.geteuid())
        if not stat.S_ISREG(st.st_mode):
            return "halt file is not a regular file"
        if st.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            # Others could lift the halt -> not trustworthy.
            return "unsafe permissions on halt file"
        if st.st_uid not in trusted:
            return "halt file owned by untrusted user"
        try:
            dst = os.stat(os.path.dirname(os.path.abspath(self._path)))
        except OSError:
            return "halt directory unreadable"
        if dst.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            # Others could replace the file.
            return "unsafe permissions on halt directory"
        if dst.st_uid not in trusted:
            return "halt directory owned by untrusted user"
        return ""

    def set(self, halted: bool, reason: str) -> HaltStatus:
        """Write the state atomically (temp file + replace), mode 0644. Raises OSError."""
        status = HaltStatus(halted=bool(halted), reason=str(reason))
        directory = os.path.dirname(os.path.abspath(self._path))
        fd, tmp = tempfile.mkstemp(dir=directory, prefix=".halt-")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(status.to_wire(), fh)
                fh.flush()
                os.fsync(fh.fileno())
            os.chmod(tmp, 0o644)
            os.replace(tmp, self._path)
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise
        return status
