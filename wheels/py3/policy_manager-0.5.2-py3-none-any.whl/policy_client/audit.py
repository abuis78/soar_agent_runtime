"""Audit log: one JSON line per event, fsynced (PM-F40-F42, W7, G5).

Fields follow docs/API.md §8. Approval ids never appear in clear text, only
the first 16 hex chars of their SHA-256 (PM-F42). Any failure raises
AuditError; callers turn that into DENY or a failed operation (PM-F41).
Several processes may share one file (SOAR workers), so writes hold an
exclusive flock. Forwarding to Splunk is the Universal Forwarder's job.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
import re
import threading
from datetime import datetime, timezone
from typing import Any
from urllib.parse import unquote

from policy_core.model import DecisionRequest

_MODE = 0o640


class AuditError(Exception):
    pass


def approval_hash(approval_id: str) -> str:
    return hashlib.sha256(str(approval_id).encode("utf-8")).hexdigest()[:16] if approval_id else ""


_APPROVAL_IN_PATH = re.compile(r"(/v1/approvals/)([^/?#\s\"']+)")


def redact_path(text: str) -> str:
    """Replace approval ids in URL paths (or log lines) by #<approval_hash> (PM-F42)."""
    return _APPROVAL_IN_PATH.sub(lambda m: m.group(1) + "#" + approval_hash(unquote(m.group(2))),
                                 text)


class AuditLog:
    def __init__(self, path: str) -> None:
        self._path = path
        self._lock = threading.Lock()

    def write(self, event: dict) -> None:
        record = {"zeit": datetime.now(timezone.utc).isoformat(), **event}
        try:
            line = (json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")
            with self._lock:
                fd = os.open(self._path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, _MODE)
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX)
                    view = memoryview(line)
                    while view:
                        view = view[os.write(fd, view):]
                    os.fsync(fd)
                finally:
                    os.close(fd)          # closing releases the flock
        except (OSError, TypeError, ValueError) as exc:
            raise AuditError(f"audit not writable ({type(exc).__name__})") from exc


def _request_fields(request: DecisionRequest) -> dict[str, Any]:
    return {
        "principal_type": request.principal_type, "initiator": request.initiator,
        "agent_id": request.agent_id, "lauf_id": request.run_id,
        "aktion": {"art": request.kind, "kategorie": request.category,
                   "playbook": request.playbook, "ziel": list(request.targets),
                   **({"schritte": [s.block for s in request.steps]} if request.steps else {})},
    }


def _sequence_field(sequence_hash: str) -> dict[str, str]:
    return {"folge_hash": sequence_hash} if sequence_hash else {}


def decide_event(client: str, request: DecisionRequest, decision: Any,
                 sequence_hash: str = "") -> dict:
    """decision is a policy_client.base.Decision; sequence_hash only for sequences (P4).
    anfrage is the whole request, so policy changes can be simulated against it (I6)."""
    return {
        "ereignis": "decide", "client": client, **_request_fields(request),
        "entscheidung_id": decision.decision_id, "freigabe_hash": approval_hash(decision.approval_id),
        "gate": decision.gate.name, "code": decision.code,
        "begruendung": [dict(r) for r in decision.reasons],
        "policy_version": decision.policy_version, **_sequence_field(sequence_hash),
        "anfrage": request.to_wire(),
    }


def approval_event(kind: str, client: str, approval_id: str, approver: str,
                   status: Any) -> dict:
    """kind is approve or reject; status is a policy_client.base.ApprovalStatus."""
    return {
        "ereignis": kind, "client": client, "freigabe_hash": approval_hash(approval_id),
        "freigebender": approver, "status": status.status, "erteilt": status.have,
        "noetig": status.need, "code": status.code,
    }


def admin_event(kind: str, client: str, person: str, reason: str, halted: bool,
                approval_id: str = "") -> dict:
    """kind is halt, resume_beantragt or resume."""
    return {
        "ereignis": kind, "client": client, "freigebender": person, "grund": reason,
        "angehalten": halted, "freigabe_hash": approval_hash(approval_id),
    }


def consume_event(client: str, approval_id: str, request: DecisionRequest, result: Any,
                  policy_version: str, sequence_hash: str = "") -> dict:
    """result is a policy_client.base.ConsumeResult."""
    return {
        "ereignis": "consume", "client": client, **_request_fields(request),
        "freigabe_hash": approval_hash(approval_id), "gueltig": result.ok, "code": result.code,
        "policy_version": policy_version, **_sequence_field(sequence_hash),
    }
