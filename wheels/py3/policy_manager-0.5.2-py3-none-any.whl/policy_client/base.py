"""Policy client interface shared by embedded and service mode (MCP-G02, RT-W01).

Python names are English; the wire format uses the spec names from
spec-policy-manager.md §5 (aktion, kontext, entscheidung_id, freigabe_id, ...).
Field names the spec does not define yet (principal_type, initiator, schritt_id,
artefakt_werte, status fields) are proposals, see docs/KONZEPT.md §7 (S3).

Fail-closed contract: no method raises to the caller. Errors become a DENY
decision with a code, a halted status, or a failed consume — a caller that
forgets error handling can never execute by accident.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass
from typing import Any

from policy_core.layer import Gate
from policy_core.model import (  # noqa: F401 (re-export)
    CODE_HALTED, CODE_INCOMPLETE_JUDGEMENT, CODE_INVALID_SEQUENCE, CODE_NO_EVIDENCE,
    CODE_NOT_ALLOWED_FOR_AGENT, CODE_POLICY_INVALID, CODE_PRINCIPAL_NOT_ALLOWED,
    DecisionRequest, _opt_float, _opt_int,
)

# Client-side codes (rule codes come from policy_core.model, PM §9).
CODE_UNAVAILABLE = "UNAVAILABLE"
CODE_INVALID_RESPONSE = "INVALID_RESPONSE"
CODE_NO_INITIATOR = "NO_INITIATOR"
CODE_AUDIT_UNAVAILABLE = "AUDIT_UNAVAILABLE"
# Approval lifecycle codes.
CODE_SELF_APPROVAL = "SELF_APPROVAL"
CODE_DUPLICATE = "DUPLICATE"
CODE_NO_APPROVER = "NO_APPROVER"
CODE_UNKNOWN_APPROVAL = "UNKNOWN_APPROVAL"
CODE_NOT_APPROVED = "NOT_APPROVED"
CODE_ACTION_CHANGED = "ACTION_CHANGED"
CODE_EXPIRED = "EXPIRED"
CODE_CONSUMED = "CONSUMED"

APPROVAL_STATES = frozenset({"pending", "approved", "rejected", "expired", "consumed"})


@dataclass(frozen=True)
class Decision:
    """Result of decide() (PM-F08)."""
    decision_id: str
    gate: Gate
    approvals_needed: int = 0
    risk_score: float = 0.0
    policy_version: str = ""
    reasons: tuple[dict, ...] = ()
    approval_id: str = ""
    expires_at: str = ""
    code: str = ""

    @property
    def allowed(self) -> bool:
        return self.gate == Gate.ALLOW

    @classmethod
    def deny(cls, code: str, reason: str = "", decision_id: str = "") -> "Decision":
        reasons = ({"regel": "client", "grund": reason, "gate": Gate.DENY.name},) if reason else ()
        return cls(decision_id=decision_id, gate=Gate.DENY, reasons=reasons, code=code)

    def to_wire(self) -> dict:
        data: dict[str, Any] = {
            "entscheidung_id": self.decision_id, "gate": self.gate.name,
            "freigaben_noetig": self.approvals_needed, "risiko_score": self.risk_score,
            "policy_version": self.policy_version, "begruendung": [dict(r) for r in self.reasons],
        }
        if self.approval_id:
            data["freigabe_id"] = self.approval_id
        if self.expires_at:
            data["ablauf"] = self.expires_at
        if self.code:
            data["code"] = self.code
        return data

    @classmethod
    def from_wire(cls, data: Any) -> "Decision":
        """Parse a wire decision. Never raises: anything malformed is DENY."""
        if not isinstance(data, dict) or "gate" not in data:
            return cls.deny(CODE_INVALID_RESPONSE, "malformed decision")
        gate = Gate.from_name(data.get("gate"))   # unknown name -> DENY
        if gate == Gate.ALLOW and not data.get("entscheidung_id"):
            # Execution must trace back to a decision (AN-06/AN-07, D22).
            return cls.deny(CODE_INVALID_RESPONSE, "ALLOW without entscheidung_id")
        needed = _opt_int(data.get("freigaben_noetig"))
        reasons = data.get("begruendung")
        return cls(
            decision_id=str(data.get("entscheidung_id") or ""),
            gate=gate,
            approvals_needed=needed if needed is not None else 0,
            risk_score=_opt_float(data.get("risiko_score")) or 0.0,
            policy_version=str(data.get("policy_version") or ""),
            reasons=tuple(r for r in reasons if isinstance(r, dict)) if isinstance(reasons, list) else (),
            approval_id=str(data.get("freigabe_id") or ""),
            expires_at=str(data.get("ablauf") or ""),
            code=str(data.get("code") or ""),
        )


@dataclass(frozen=True)
class ApprovalStatus:
    """State of an approval (GET /v1/approvals/{id})."""
    approval_id: str
    status: str            # one of APPROVAL_STATES; anything else is treated as expired
    have: int = 0
    need: int = 0
    code: str = ""         # why an approve/reject was not counted, e.g. SELF_APPROVAL

    def to_wire(self) -> dict:
        data: dict[str, Any] = {"freigabe_id": self.approval_id, "status": self.status,
                                "erteilt": self.have, "noetig": self.need}
        if self.code:
            data["code"] = self.code
        return data

    @classmethod
    def from_wire(cls, data: Any) -> "ApprovalStatus":
        data = data if isinstance(data, dict) else {}
        status = str(data.get("status") or "")
        return cls(
            approval_id=str(data.get("freigabe_id") or ""),
            status=status if status in APPROVAL_STATES else "expired",
            have=_opt_int(data.get("erteilt")) or 0,
            need=_opt_int(data.get("noetig")) or 0,
            code=str(data.get("code") or ""),
        )


@dataclass(frozen=True)
class ConsumeResult:
    """Outcome of consume() (PM-F23). Only ok=True permits execution."""
    ok: bool
    code: str = ""

    def to_wire(self) -> dict:
        data: dict[str, Any] = {"gueltig": self.ok}
        if self.code:
            data["code"] = self.code
        return data

    @classmethod
    def from_wire(cls, data: Any) -> "ConsumeResult":
        if not isinstance(data, dict) or data.get("gueltig") is not True:
            code = str(data.get("code") or "") if isinstance(data, dict) else ""
            return cls(ok=False, code=code or CODE_INVALID_RESPONSE)
        return cls(ok=True, code=str(data.get("code") or ""))


@dataclass(frozen=True)
class HaltStatus:
    """Emergency stop state (PM-F30/F31). Unknown state means halted.

    known=False marks a state that could not be determined (service unreachable,
    halt file missing or unreadable). Callers tell an outage from a deliberate
    halt by this flag, never by the reason text."""
    halted: bool
    reason: str = ""
    known: bool = True

    def to_wire(self) -> dict:
        return {"angehalten": self.halted, "grund": self.reason, "bekannt": self.known}

    @classmethod
    def from_wire(cls, data: Any) -> "HaltStatus":
        if not isinstance(data, dict) or not isinstance(data.get("angehalten"), bool):
            reason = str(data.get("grund") or "") if isinstance(data, dict) else ""
            return cls(halted=True, reason=reason or "unknown halt state", known=False)
        reason = str(data.get("grund") or "")
        # Missing "bekannt" = known (older counterparts); anything but true counts as unknown.
        known = data.get("bekannt", True) is True
        if not known:
            return cls(halted=True, reason=reason or "unknown halt state", known=False)
        return cls(halted=data["angehalten"], reason=reason)


class PolicyClient(abc.ABC):
    """One interface for embedded and service mode. Implementations never raise."""

    @abc.abstractmethod
    def decide(self, request: DecisionRequest) -> Decision:
        """POST /v1/decide."""

    @abc.abstractmethod
    def approve(self, approval_id: str, approver: str) -> ApprovalStatus:
        """POST /v1/approvals/{id}/approve — one authenticated person (PM-F21)."""

    @abc.abstractmethod
    def reject(self, approval_id: str, approver: str) -> ApprovalStatus:
        """POST /v1/approvals/{id}/reject."""

    @abc.abstractmethod
    def approval_status(self, approval_id: str) -> ApprovalStatus:
        """GET /v1/approvals/{id}."""

    @abc.abstractmethod
    def consume(self, approval_id: str, request: DecisionRequest) -> ConsumeResult:
        """POST /v1/approvals/{id}/consume — valid only for the unchanged action."""

    @abc.abstractmethod
    def halt_status(self) -> HaltStatus:
        """GET /v1/halt."""

    @abc.abstractmethod
    def actions(self, agent_id: str) -> list[dict]:
        """GET /v1/aktionen?agent_id= — empty list means no building blocks."""

    @abc.abstractmethod
    def pending_approvals(self) -> list[dict]:
        """GET /v1/approvals?status=pending — open approvals (PM-F54); empty list on any error."""
