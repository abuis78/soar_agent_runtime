"""Policy Manager client for SOAR apps: embedded and service mode (MCP-G02, RT-W01)."""
