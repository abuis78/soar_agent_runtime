"""Embedded mode: the policy decision runs in-process (E8, SPEC-RT phase 3).

EmbeddedPolicyClient decides with policy_core.engine (policy layer 1:1 with
soar_mcp_server plus the P2 rules), keeps approvals in a file-backed
LifecycleStore and reads the emergency stop from a halt file (E9), which the
engine gets as input. No approval is opened without an initiator (the action
stays held, like today without a scoped token).

LifecycleStore reuses ApprovalStore's file, lock and hashing, but separates
approve from consume (PM-F23): pending -> approved -> consumed, or rejected /
expired. Approvals are bound to the action (art, kategorie, playbook, ziel,
parameter) only — a changed judgement or context does not break consume (W6).
Only SHA-256 hashes of approval ids are stored (PM-F42).

Sequences (P4): with a sequences_path, an approved sequence is recorded in the
register when it is consumed (PM-F11); without one, every sequence is new.
"""
from __future__ import annotations

import hashlib
import logging
import secrets
import time
from dataclasses import replace
from datetime import datetime, timezone
from typing import Callable, Optional

from policy_client.approvals import ApprovalStore, identity_key
from policy_client.audit import (
    AuditError, AuditLog, approval_event, consume_event, decide_event,
)
from policy_client.base import (
    CODE_ACTION_CHANGED, CODE_AUDIT_UNAVAILABLE, CODE_CONSUMED, CODE_DUPLICATE, CODE_EXPIRED,
    CODE_HALTED, CODE_NO_APPROVER, CODE_NO_INITIATOR, CODE_NOT_APPROVED,
    CODE_PRINCIPAL_NOT_ALLOWED, CODE_SELF_APPROVAL, CODE_UNAVAILABLE, CODE_UNKNOWN_APPROVAL, ApprovalStatus, ConsumeResult, Decision,
    DecisionRequest, HaltStatus, PolicyClient,
)
from policy_client.halt import HaltFile
from policy_client.register import SequenceRegister
from policy_core import sequence
from policy_core.engine import PolicyEngine
from policy_core.layer import Gate
from policy_core.model import PRINCIPAL_AGENT, PRINCIPAL_HUMAN

log = logging.getLogger("policy_client.embedded")

_CLIENT = "embedded"          # client field of audit events
_TTL_DEFAULT = 600.0          # 10 min, as today (PM-F22)
_KEEP_AFTER_EXPIRY = 3600.0   # keep finished entries so status queries stay meaningful


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).isoformat()


def _binding(request: DecisionRequest) -> dict:
    """What an approval is bound to: the action itself, never its context (W6).
    Steps only for sequences, so single actions keep their binding."""
    binding = {"art": request.kind, "kategorie": request.category, "playbook": request.playbook,
               "ziel": list(request.targets), "parameter": dict(request.params)}
    if request.steps:
        binding["schritte"] = [s.to_wire() for s in request.steps]
    return binding


class LifecycleStore(ApprovalStore):
    """Approval lifecycle with separate consume. Entries are dicts:
    {tool, args, exp, need, approvers, initiator, principal, state}."""

    @staticmethod
    def _prune(data: dict) -> dict:
        now = time.time()
        return {k: v for k, v in data.items()
                if isinstance(v, dict) and float(v.get("exp", 0)) + _KEEP_AFTER_EXPIRY > now}

    def open(self, tool: str, args: dict, needed: int, initiator: str, principal: str,
             ttl: float = _TTL_DEFAULT) -> tuple[str, float]:
        token = "ap_" + secrets.token_urlsafe(16)
        exp = time.time() + ttl
        with self._lock, self._file_lock():
            data = self._prune(self._load())
            data[self._token_hash(token)] = {
                "tool": tool, "args": self._args_hash(tool, args), "exp": exp,
                "need": max(1, int(needed)), "approvers": [], "initiator": identity_key(initiator),
                "principal": principal, "state": "pending",
            }
            self._save(data)
        return token, exp

    @staticmethod
    def _status(token: str, entry: Optional[dict], code: str = "") -> ApprovalStatus:
        if entry is None:
            return ApprovalStatus(token, "expired", code=code or CODE_UNKNOWN_APPROVAL)
        return ApprovalStatus(token, entry["state"], have=len(entry["approvers"]),
                              need=int(entry["need"]), code=code)

    @staticmethod
    def _expire(entry: dict) -> None:
        if entry["state"] in ("pending", "approved") and float(entry["exp"]) <= time.time():
            entry["state"] = "expired"

    def _entry(self, data: dict, token: str) -> Optional[dict]:
        entry = data.get(self._token_hash(str(token)))
        return entry if isinstance(entry, dict) else None

    def kind(self, token: str) -> Optional[str]:
        """Tool the approval is bound to, or None if unknown."""
        with self._lock, self._file_lock():
            entry = self._entry(self._load(), token)
            return str(entry["tool"]) if entry is not None else None

    def status(self, token: str) -> ApprovalStatus:
        with self._lock, self._file_lock():
            entry = self._entry(self._load(), token)
            if entry is not None:
                self._expire(entry)
            return self._status(token, entry)

    def _commit(self, data: dict, token: str, entry: dict, before: dict, code: str,
                before_save: Optional[Callable[[ApprovalStatus], bool]]) -> ApprovalStatus:
        """Store a state change only once before_save (the audit) accepted it (F14).
        Refused -> nothing is stored, the unchanged state is reported."""
        status = self._status(token, entry, code)
        if before_save is not None and not before_save(status):
            return self._status(token, before, CODE_AUDIT_UNAVAILABLE)
        self._save(data)
        return status

    def approve(self, token: str, approver: str, halted: bool,
                before_save: Optional[Callable[[ApprovalStatus], bool]] = None) -> ApprovalStatus:
        approver = identity_key(approver)   # one person, one vote (F4, F8)
        with self._lock, self._file_lock():
            data = self._load()
            entry = self._entry(data, token)
            if entry is None:
                return self._status(token, None)
            self._expire(entry)
            if entry["state"] != "pending":
                return self._status(token, entry, CODE_EXPIRED if entry["state"] == "expired" else "")
            if not approver:
                return self._status(token, entry, CODE_NO_APPROVER)
            before = dict(entry, approvers=list(entry["approvers"]))
            if entry["principal"] == "agent" and halted:
                entry["state"] = "expired"   # open agent approvals become invalid (PM-F30)
                return self._commit(data, token, entry, before, CODE_HALTED, before_save)
            if entry["initiator"] and approver == entry["initiator"]:
                return self._status(token, entry, CODE_SELF_APPROVAL)
            if approver in entry["approvers"]:
                return self._status(token, entry, CODE_DUPLICATE)
            entry["approvers"].append(approver)
            if len(entry["approvers"]) >= int(entry["need"]):
                entry["state"] = "approved"
            return self._commit(data, token, entry, before, "", before_save)

    def reject(self, token: str, approver: str) -> ApprovalStatus:
        approver = (approver or "").strip()
        with self._lock, self._file_lock():
            data = self._load()
            entry = self._entry(data, token)
            if entry is None:
                return self._status(token, None)
            self._expire(entry)
            if not approver:
                return self._status(token, entry, CODE_NO_APPROVER)
            if entry["state"] in ("pending", "approved"):
                entry["state"] = "rejected"
                self._save(data)
            return self._status(token, entry)

    def pending(self) -> list[dict]:
        """Open approvals, oldest expiry first (PM-F54). Keys are the stored SHA-256 hashes
        of the ids; their first 16 hex chars are the freigabe_hash of the audit."""
        with self._lock, self._file_lock():
            data = self._load()
        now = time.time()
        open_entries = sorted((float(e["exp"]), key, e) for key, e in data.items()
                              if isinstance(e, dict) and e.get("state") == "pending"
                              and float(e.get("exp", 0)) > now)
        return [{"freigabe_hash": key[:16], "art": str(e["tool"]), "status": "pending",
                 "erteilt": len(e["approvers"]), "noetig": int(e["need"]), "ablauf": _iso(exp),
                 "initiator": e["initiator"], "principal_type": e["principal"]}
                for exp, key, e in open_entries]

    def consume(self, token: str, tool: str, args: dict, halted: bool) -> ConsumeResult:
        with self._lock, self._file_lock():
            data = self._load()
            entry = self._entry(data, token)
            if entry is None:
                return ConsumeResult(False, CODE_UNKNOWN_APPROVAL)
            self._expire(entry)
            state = entry["state"]
            if state == "consumed":
                return ConsumeResult(False, CODE_CONSUMED)
            if state == "expired":
                return ConsumeResult(False, CODE_EXPIRED)
            if state != "approved":
                return ConsumeResult(False, CODE_NOT_APPROVED)
            # Changed action must NOT destroy a legitimate approval.
            if entry["tool"] != tool or entry["args"] != self._args_hash(tool, args):
                return ConsumeResult(False, CODE_ACTION_CHANGED)
            if entry["principal"] == "agent" and halted:
                entry["state"] = "expired"   # PM-F30
                self._save(data)
                return ConsumeResult(False, CODE_HALTED)
            entry["state"] = "consumed"      # single use (PM-F22/F23)
            self._save(data)
            return ConsumeResult(True)


class EmbeddedPolicyClient(PolicyClient):
    """In-process policy decisions. Never raises; errors fail closed."""

    def __init__(self, policy_path: str, approvals_path: str, halt_path: str,
                 ttl: float = _TTL_DEFAULT, audit_path: Optional[str] = None,
                 audit_client: str = _CLIENT, sequences_path: Optional[str] = None,
                 allowed_principals: Optional[frozenset[str]] = None) -> None:
        self._engine = PolicyEngine(policy_path)     # missing/broken -> DENY
        self._version = self._file_version(policy_path)
        self._store = LifecycleStore(approvals_path)
        self._halt = HaltFile(halt_path)
        self._ttl = ttl
        # Optional (G5). With an audit path, nothing takes effect unaudited (PM-F41).
        self._audit = AuditLog(audit_path) if audit_path else None
        self._client = audit_client
        self._register = SequenceRegister(sequences_path) if sequences_path else None
        # Service mode: principal types this client identity may claim (F1). None = any.
        self._principals = allowed_principals

    def _write_audit(self, event: dict) -> bool:
        if self._audit is None:
            return True
        try:
            self._audit.write(event)
            return True
        except AuditError as exc:
            log.error("[policy_client] %s", exc)
            return False

    @staticmethod
    def _file_version(path: str) -> str:
        try:
            with open(path, "rb") as fh:
                return hashlib.sha256(fh.read()).hexdigest()[:12]
        except OSError:
            return ""

    def _halted(self) -> bool:
        return self.halt_status().halted

    def _sequence(self, request: DecisionRequest) -> tuple[str, bool]:
        """(register hash, known) of a sequence; ("", False) for anything else."""
        key = sequence.sequence_hash(request, self._engine.catalog)
        return key, bool(key and self._register and self._register.contains(key))

    def _principal_denied(self, request: DecisionRequest, decision_id: str) -> Optional[Decision]:
        """DENY if the client identity may not claim this principal type (F1, PM §8).
        Types that are never valid (empty, broker, ...) are left to the principal rule."""
        if self._principals is None or request.principal_type in self._principals \
                or request.principal_type not in (PRINCIPAL_HUMAN, PRINCIPAL_AGENT):
            return None
        reason = {"regel": "principal_bindung", "gate": Gate.DENY.name,
                  "grund": f"principal_type={request.principal_type} "
                           f"not allowed for client {self._client}"}
        return Decision(decision_id=decision_id, gate=Gate.DENY, policy_version=self._version,
                        reasons=(reason,), code=CODE_PRINCIPAL_NOT_ALLOWED)

    def decide(self, request: DecisionRequest) -> Decision:
        try:
            key, known = self._sequence(request)
            decision = self._decide(request, known)
            if not self._write_audit(decide_event(self._client, request, decision, key)):
                # The approval id (if any) is never handed out.
                return Decision.deny(CODE_AUDIT_UNAVAILABLE, "audit not writable",
                                     decision_id=decision.decision_id)
            return decision
        except Exception as exc:
            log.error("[policy_client] decide failed: %s -> DENY", exc)
            return Decision.deny(CODE_UNAVAILABLE, f"embedded decide failed ({type(exc).__name__})")

    def simulate(self, request: DecisionRequest) -> Decision:
        """Decision without effect: no approval process, no audit (PM-F09)."""
        try:
            denied = self._principal_denied(request, "sim-" + secrets.token_hex(8))
            if denied is not None:
                return denied
            out = self._engine.evaluate(request, halted=self._halted(),
                                        sequence_known=self._sequence(request)[1])
            return Decision(decision_id="sim-" + secrets.token_hex(8), gate=out.gate,
                            approvals_needed=out.approvals_needed, risk_score=out.risk_score,
                            policy_version=self._version, reasons=out.reasons, code=out.code)
        except Exception as exc:
            log.error("[policy_client] simulate failed: %s -> DENY", exc)
            return Decision.deny(CODE_UNAVAILABLE, f"embedded simulate failed ({type(exc).__name__})")

    @property
    def policy_version(self) -> str:
        return self._version

    @property
    def engine(self) -> PolicyEngine:
        return self._engine

    def _decide(self, request: DecisionRequest, sequence_known: bool) -> Decision:
        decision_id = "pm-" + secrets.token_hex(8)
        denied = self._principal_denied(request, decision_id)
        if denied is not None:
            return denied
        out = self._engine.evaluate(request, halted=self._halted(), sequence_known=sequence_known)
        decision = Decision(decision_id=decision_id, gate=out.gate,
                            approvals_needed=out.approvals_needed, risk_score=out.risk_score,
                            policy_version=self._version, reasons=out.reasons, code=out.code)
        if out.gate not in (Gate.APPROVE_1CLICK, Gate.APPROVE_2PERSON):
            return decision
        if not request.initiator.strip():
            # No accountable initiator -> no approval process, action stays held.
            return replace(decision, code=CODE_NO_INITIATOR)
        token, exp = self._store.open(request.kind, _binding(request), out.approvals_needed,
                                      request.initiator, request.principal_type, self._ttl)
        return replace(decision, approval_id=token, expires_at=_iso(exp))

    def approve(self, approval_id: str, approver: str) -> ApprovalStatus:
        try:
            audited = []

            def audit(status: ApprovalStatus) -> bool:   # runs before the vote is stored (F14)
                audited.append(status)
                return self._write_audit(approval_event("approve", self._client, approval_id,
                                                        approver, status))

            status = self._store.approve(approval_id, approver, self._halted(), before_save=audit)
            if audited:
                return status
            if not self._write_audit(approval_event("approve", self._client, approval_id, approver, status)):
                return replace(status, code=CODE_AUDIT_UNAVAILABLE)
            return status
        except Exception as exc:
            log.error("[policy_client] approve failed: %s", exc)
            return ApprovalStatus(approval_id, "expired", code=CODE_UNAVAILABLE)

    def reject(self, approval_id: str, approver: str) -> ApprovalStatus:
        try:
            status = self._store.reject(approval_id, approver)
            if not self._write_audit(approval_event("reject", self._client, approval_id, approver, status)):
                return replace(status, code=CODE_AUDIT_UNAVAILABLE)
            return status
        except Exception as exc:
            log.error("[policy_client] reject failed: %s", exc)
            return ApprovalStatus(approval_id, "expired", code=CODE_UNAVAILABLE)

    def approval_status(self, approval_id: str) -> ApprovalStatus:
        try:
            return self._store.status(approval_id)
        except Exception as exc:
            log.error("[policy_client] approval_status failed: %s", exc)
            return ApprovalStatus(approval_id, "expired", code=CODE_UNAVAILABLE)

    def consume(self, approval_id: str, request: DecisionRequest) -> ConsumeResult:
        try:
            result = self._store.consume(approval_id, request.kind, _binding(request), self._halted())
            key = sequence.sequence_hash(request, self._engine.catalog)
            if not self._write_audit(consume_event(self._client, approval_id, request, result,
                                                   self._version, key)):
                return ConsumeResult(False, CODE_AUDIT_UNAVAILABLE)   # approval is spent
            if result.ok and key and self._register is not None:
                self._remember(request, key)
            return result
        except Exception as exc:
            log.error("[policy_client] consume failed: %s", exc)
            return ConsumeResult(False, CODE_UNAVAILABLE)

    def _remember(self, request: DecisionRequest, key: str) -> None:
        """Record a consumed sequence (PM-F11). Failure only keeps it "new" (fail-closed)."""
        blocks = [[b.id, b.version] for b in sequence.blocks_of(request, self._engine.catalog)
                  if b is not None]
        try:
            self._register.add(key, blocks)
        except OSError as exc:
            log.error("[policy_client] sequence register not writable (%s); sequence stays new",
                      type(exc).__name__)

    def halt_status(self) -> HaltStatus:
        try:
            return self._halt.status()
        except Exception as exc:
            return HaltStatus(halted=True, reason=f"halt check failed ({type(exc).__name__})",
                              known=False)

    def actions(self, agent_id: str) -> list[dict]:
        try:
            return self._engine.actions(agent_id)
        except Exception as exc:
            log.error("[policy_client] actions failed: %s", type(exc).__name__)
            return []

    def pending_approvals(self) -> list[dict]:
        try:
            return self._store.pending()
        except Exception as exc:
            log.error("[policy_client] pending_approvals failed: %s", type(exc).__name__)
            return []
