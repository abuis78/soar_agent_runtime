"""Register of approved sequences (P4.5, PM-F11, H7).

A sequence of two or more building blocks that was approved and consumed once
is recorded by its hash (policy_core.sequence.sequence_hash). Fail-closed: a
missing, unreadable or malformed file means "not in register", so the sequence
needs at least APPROVE_1CLICK again. Deleting the file resets every sequence to
new, which is the safe direction.

    {"folgen": {"<hash>": {"bausteine": [["isolate_endpoint", 2], ...], "seit": "<iso>"}}}
"""
from __future__ import annotations

import contextlib
import fcntl
import json
import os
import tempfile
from datetime import datetime, timezone


class SequenceRegister:
    def __init__(self, path: str) -> None:
        self._path = path

    def _load(self) -> dict:
        try:
            with open(self._path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return {}
        entries = data.get("folgen") if isinstance(data, dict) else None
        return entries if isinstance(entries, dict) else {}

    def contains(self, sequence_hash: str) -> bool:
        return bool(sequence_hash) and sequence_hash in self._load()

    @contextlib.contextmanager
    def _lock(self):
        """Exclusive cross-process lock around read-modify-write (as the approval store)."""
        with open(self._path + ".lock", "w", encoding="utf-8") as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            yield

    def add(self, sequence_hash: str, blocks: list[list]) -> None:
        """Record a sequence atomically (temp file + fsync + replace). Raises OSError."""
        if not sequence_hash:
            return
        directory = os.path.dirname(os.path.abspath(self._path))
        with self._lock():
            entries = self._load()
            if sequence_hash in entries:
                return
            entries[sequence_hash] = {"bausteine": blocks,
                                      "seit": datetime.now(timezone.utc).isoformat()}
            fd, tmp = tempfile.mkstemp(dir=directory, prefix=".sequences-")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump({"folgen": entries}, fh, indent=1)
                    fh.flush()
                    os.fsync(fh.fileno())
                os.chmod(tmp, 0o640)
                os.replace(tmp, self._path)
            except BaseException:
                if os.path.exists(tmp):
                    os.unlink(tmp)
                raise
